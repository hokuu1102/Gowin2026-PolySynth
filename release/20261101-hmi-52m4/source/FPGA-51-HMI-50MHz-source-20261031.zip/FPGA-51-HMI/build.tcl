open_project Gowin2026.gprj
set_option -top_module top
set_option -place_option 1
run all
exit
