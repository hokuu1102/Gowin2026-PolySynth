`timescale 1ns/1ps
// ─────────────────────────────────────────────────────────────────────────────
// seq_arb.v · 源 A 三级仲裁（手弹 / 曲谱 / 演示 → `evt_merge` 源 A）
//   —— W3c（⭐ 2026-09-26 新增，⭐ 补 `top.v:1520` 的 TODO）
//
// ── 🔴 它解决什么问题 ────────────────────────────────────────────────────────
//   `evt_merge` 的**源 A 只有一个入口**，⚠️ 而现在有【3 个来源】都往里挤：
//     ① ⭐ **手弹**（W3a 采集链：琴键 → `event_extract`）
//     ② ⭐ **曲谱**（`evt_uart_rx`：串口灌进来的事件）
//     ③ ⭐ **演示**（`DEMO_CHORD_ON`：复位后自动起一个三音和弦，⭐ 自检用）
//
//   ⚠️ 原来的做法是一个**编译期二选一参数** `SOURCE_A_SEL`（0=手弹 / 1=演示），
//      🔴 **曲谱根本挤不进去** ⇒ ⭐ 灌了曲谱**不会响**。
//
//   📌 `top.v` 自己的注释（⭐ 原文）：
//      *"TODO（曲谱接入时）：那时源 A 要有 3 个来源（手弹/曲谱/演示）
//        ⇒ 应改成 `evt_merge` 前再加一级仲裁"* ⇒ ⭐ **本模块就是那一级**。
//
// ── ⭐⭐ 实现：直接复用 `evt_merge` 的【已验证】手法 ─────────────────────────
//   ⚠️ **为什么不重新设计**：`evt_merge` 是**穷举验证过**的
//      （⭐ 它的第一版用"1 个待发寄存器" ⇒ 🔴 **穷举后发现 2 种组合会丢**）
//      ⇒ ⭐ **同一类问题、同一个解法** ⇒ ⭐ **照抄它的环形 FIFO，⛔ 不发明新的**。
//
//   ⭐ 环形 FIFO，深度 `DEPTH`（默认 **6**）：
//      · ⭐ **每拍最多推入 3 条**（A/B/C 各一条）、**弹出 1 条**
//      · ⭐ **弹出优先于推入**（先腾位置）⇒ `cnt_next = cnt + push - pop`
//      · ⚠️ 队列空时**不弹**（避免吐垃圾）⇒ 代价是**首次入队晚 1 拍**（20 ns）
//
// ── 🔴 深度为什么是 6（⭐ 算过，⛔ 不是拍脑袋）───────────────────────────────
//   ⚠️ `evt_merge` 的教训：⭐ **深度要按"最坏在飞条数"算**。
//   本模块最坏：⭐ 队列里已有 `DEPTH-1` 条 + 本拍又来 3 条 ⇒ ⚠️ **需要 DEPTH+2**。
//   ⭐ 但和 `evt_merge` 一样，⭐ **实际源速率远低于 1 条/拍**：
//      · 手弹：⭐ 人手指最快 ~10 次/秒（⭐ 而 1 拍 = 20 ns ⇒ 密度可忽略）
//      · 曲谱：⭐ `play_seq` **≤1 条/tick**，⭐ tick = 960/四分音符
//      · 演示：⭐ 只发 **3+3 = 6 条**（⭐ 起音 3 + 收音 3）⇒ ⚠️ 瞬时，⛔ 不持续
//   ⇒ ⭐ **深度 6 有大量余量**（⭐ 20 倍以上）。⚠️ 万一溢出 ⇒ ⭐ **必须看得见**。
//
// ── ⭐⭐ 关于"能不能保证【永不】丢"（⚠️ 诚实的边界）──────────────────────────
//   ⚠️ 3 个源各以 1 条/拍持续输入 = 3 条/拍，而出口只有 1 条/拍
//      ⇒ ⭐ **任何有限深度都会溢出**（⭐ 这是信息论的，⛔ 不是实现问题）。
//   ⇒ ⭐ 本模块的承诺和 `evt_merge` 一样，是**两级的**：
//      ① ⭐ **在实际源速率下【不丢】**（⭐ 见上：密度远低于 1 条/拍）
//      ② ⭐⭐ **万一溢出【必须看得见】**：`overflow_o`（sticky）+ `drop_cnt_o`
//         ⇒ ⛔ **不静默丢**（`K-106` 纪律）
//   ⇒ ⭐ **"能证明的上界"比"声称不会发生"可靠**。
//
// ── ⭐ 优先级（⭐ 与"轮转"配合，⛔ 不饿死任何一方）──────────────────────────
//   ⭐ **固定优先级**：⭐ **手弹 > 曲谱 > 演示**
//      ⇒ ⭐ 理由：⭐ **人优先于机器** —— ⚠️ 演奏者按下琴键时，
//         ⭐ 那个音**必须**立刻发出去（⭐ 延迟是手感的一部分）。
//
//   ⚠️ 但**光有固定优先级不够**：⭐ 若"手弹每拍都有"，🔴 曲谱会被**永久饿死**。
//   ⇒ ⭐ 本模块用**两级机制**：
//      · ⭐ **推入顺序**按"真实做过取舍则轮转"（⭐ 同 `evt_merge`）——
//        ⭐ 保证两个源**轮流先出队**
//      · ⭐ **演示优先让位**：⭐ `demo_active_i` 拉起时，⚠️ 若 A/B 也有事件，
//        ⭐ **演示不参与**（⭐ 它是"自检"，⛔ 不该和真演奏抢）
//   📌 **为什么不用"绝对优先级"**：⚠️ 绝对优先级 ⇒ 🔴 **低优先级源被饿死**
//      （⭐ 这正是 `evt_merge` 注释里"⛔ 不饿死任何一方"那条）。
//
// ── ⛔ 纪律（本项目血泪）────────────────────────────────────────────────────
//   · ⭐ **Verilog-2001 语法**（`K-91`：Gowin 按 2001 编译，用 SV 专有构造
//     ⇒ **整个模块被静默丢弃**，而 iverilog 全绿）
//   · ⭐ **不对 `integer` 参数做位选**（`K-91`）⇒ ⭐ 先落到定宽 `localparam`
//   · 🔴 **`wire` 必须显式写位宽**（⚠️ `evt_merge` 踩过：`wire push_n` 隐含 1 bit
//     ⇒ `1+1` 截成 0 ⇒ ⭐ **"两路同拍相撞"恰好什么都不做**）
//   · ⭐ **组合逻辑用 `assign`**（`L67`）· ⭐ 单时钟域、⛔ 不用 PLL/CPU/HLS
//   · ⭐ **声明必须先于使用**（`L66`）
// ─────────────────────────────────────────────────────────────────────────────
`default_nettype none

module seq_arb #(
    parameter integer AXIS_W  = 4,
    parameter integer PHASE_W = 32,
    parameter integer VEL_W   = 8,
    parameter integer KIND_W  = 2,
    parameter integer TIMBRE_W = 2,
    // ⭐ FIFO 深度。⚠️ 必须 ≥ 3（⚠️ 否则"待发 + 同拍来 3 条"就装不下 ——
    //    ⭐ 那正是 `evt_merge` 第一版的 bug 模式）。⭐ 默认 6 留足余量。
    parameter integer DEPTH   = 6
) (
    input  wire                  clk_i,
    input  wire                  rst_n_i,

    // ── ⭐ 源 1：手弹（W3a 采集链）—— ⭐ 最高优先 ───────────────────────────
    input  wire                  live_valid_i,
    input  wire [AXIS_W-1:0]     live_axis_i,
    input  wire [PHASE_W-1:0]    live_phase_inc_i,
    input  wire [VEL_W-1:0]      live_velocity_i,
    input  wire [KIND_W-1:0]     live_kind_i,
    input  wire                  live_timbre_valid_i,
    input  wire [TIMBRE_W-1:0]   live_timbre_i,

    // ── ⭐ 源 2：曲谱（`evt_uart_rx` → 串口灌入）────────────────────────────
    input  wire                  score_valid_i,
    input  wire [AXIS_W-1:0]     score_axis_i,
    input  wire [PHASE_W-1:0]    score_phase_inc_i,
    input  wire [VEL_W-1:0]      score_velocity_i,
    input  wire [KIND_W-1:0]     score_kind_i,
    input  wire                  score_timbre_valid_i,
    input  wire [TIMBRE_W-1:0]   score_timbre_i,

    //  ── ⭐⭐ 2026-10-16：⭐ **"这条曲谱事件是不是鼓"的【显式标志】** ─────────────
    //     🔴 **为什么必须【从外面】送进来**（⭐ 用户拍板的红线 1：
    //        *"旋律线【绝对不能】变成鼓"*）：
    //        ⚠️ 原来的判据是 **`score_axis_i >= 4'd12`** —— 🔴 **靠轴号猜"是不是鼓"** ✅
    //        ⇒ ⭐ **旋律轨只要用到轴 12..15 就必被读成鼓**（⭐ "退到 0..11"只是个
    //           **约定**，⭐ ⛔ 没有任何机械保证）⇒ 🔴 **旋律变鼓声** ✅
    //     ✅ **新接口**：⭐ `score_is_drum_i`（⭐ 1 = 鼓）＋ `score_drum_type_i`
    //        （⭐ 2 位：0=Kick · 1=Snare · 2=HiHat · 3=Tom ⇒ ⭐ 决定用哪个 `INC_*`）✅
    //        ⇒ ⭐ **轴号彻底退出判定**（⭐ `score_axis_i` 只剩"事件轴号"这一个用途，
    //           ⭐ 与 `evt_axis_o` 一起原样透传 ✅）
    //     📌 ⭐ **位域来源**（⭐ `top.v` 的 `ps_is_drum` / `ps_drum_type`）：
    //        ⭐ **`bit5` = `is_drum`** · ⭐ **`bit[8:7]` = `drum_type`**（⭐ 复用 timbre 字段）
    //        ⛔ **`axis[22:19]` 一个字节都不动** ⇒ ⭐ 旧上位机写的轨号
    //        **不会再被误读成鼓**（⭐ 这是本改动的全部目的）✅
    //     ⚠️ **必须与 `score_valid_i`【同一拍】**（⭐ 否则判定与事件错拍 ⇒
    //        🔴 会拿"下一条的鼓标志"去判"这一条" ✅）
    input  wire                  score_is_drum_i,
    input  wire [1:0]            score_drum_type_i,

    // ── ⭐ 源 3：演示（`DEMO_CHORD_ON` 自检和弦）—— ⭐ 最低优先 ─────────────
    input  wire                  demo_valid_i,
    input  wire [AXIS_W-1:0]     demo_axis_i,
    input  wire [PHASE_W-1:0]    demo_phase_inc_i,
    input  wire [VEL_W-1:0]      demo_velocity_i,
    input  wire [KIND_W-1:0]     demo_kind_i,
    input  wire                  demo_timbre_valid_i,
    input  wire [TIMBRE_W-1:0]   demo_timbre_i,

    // ── 仲裁后的唯一出口（→ `evt_merge` 的源 A）────────────────────────────
    output reg                   evt_valid_o,
    output reg  [AXIS_W-1:0]     evt_axis_o,
    //  ⭐⭐ 2026-10-16（🔴 修 P0-1/P0-2）：⭐ **上行专用的"鼓标记"轴**（⭐ 只给上行帧）✅
    //     🔴 **原缺陷**：⭐ 我直接把 `evt_axis_o` 改成"鼓回传 drum_type、其余回传 0"⇒
    //        ⚠️ 而 `evt_axis_o` 有【两个消费者】（⭐ `top.v` 里）：
    //          · `top.v:5968` `.evt_axis_i(mg_evt_axis)`   ← 上行回传帧（⭐ 要鼓标记 ✅）
    //          · `top.v:6052` `.note_axis_i(mg_evt_axis)`  ← 下行 note_manager 的
    //            【voice 定位键】（⭐ 按 (axis, src) 配对 note_on/off ✅）
    //        ⇒ 🔴 改一处 = 同时改两边 ⇒ 两个 P0：
    //          · **P0-1**：⭐ 下行轴被压成 0/1/2/3 ⇒ `top.v:5688 key_drum_sel =
    //            src_a_axis[3:2]` 恒 0 ⇒ ⭐ **鼓垫四件退化成一件** ✅
    //            且灌谱鼓落 (0/1/2/3, src=SRC_KDRUM) 与鼓机鼓 (12/13/14/15, src=SRC_AUX)
    //            ⇒ ⭐ **同一件鼓三条来路三个身份、永不重触发** ✅
    //          · **P0-2**：⭐ 鼓的 note_off 轴来源从"帧 axis[22:19]"换成"帧 [8:7]"⇒
    //            ⚠️ 而上位机【没有义务】在 off 帧也填同样的 [8:7] ⇒ on/off 轴不同
    //            ⇒ ⭐ **note_off 匹配不上 ⇒ 鼓 voice 永久 held ⇒ RESERVED_N=5 保留池耗尽** ✅
    //     ✅ **修法**：⭐ 上下行【拆开两条独立输出】，`evt_axis_o` 逐位恢复"原样透传"✅
    //        ⇒ ⭐ 下行定位键回到改动前（⭐ 零回归）· ⭐ 上行仍拿到鼓标记 ✅
    //     📌 端口加在 `evt_axis_o` 旁边，⛔ 不移动其它端口（⭐ 否则老例化全错位 ✅）
    output reg  [AXIS_W-1:0]     evt_up_axis_o,
    output reg  [PHASE_W-1:0]    evt_phase_inc_o,
    output reg  [VEL_W-1:0]      evt_velocity_o,
    output reg  [KIND_W-1:0]     evt_kind_o,
    output reg                   evt_timbre_valid_o,
    output reg  [TIMBRE_W-1:0]   evt_timbre_o,
    //  ⭐⭐ 2026-09-29（A1）：⭐ **事件来源标记** —— ⭐ 与 `evt_valid_o` **同时序**
    //     ⭐ 编码 = 内部 `SRC_*`（⭐ 0=live 手弹 / 1=score 曲谱 / 2=demo 演示）
    //     ⚠️ 位宽**写死 3** —— `NW` 是模块体内的 `localparam`，⭐ ANSI 端口表在它之前
    //        ⇒ ⛔ 不能引用（`K-91` 同族纪律：⛔ 不对参数做位选）
    //     ⭐ 用途：⭐ 下游 `note_manager` 据此**按源**区分 `note_off`
    //        ⇒ ⭐ 曲谱（`score`）的 `note_off` ⛔ 不再误杀手弹（`live`）的同轴 voice
    //  ⭐⭐ 2026-09-30：⭐ **2 位加宽到 3 位**（⭐ 用户需求：曲谱 UART 与 looper **同时可用**）
    //   🔴 **为什么必须加宽**（⭐ 这是本模块唯一为它做的改动）：
    //      ⭐ 原来 2 位 = **4 个值全部用满**（0=live · 1=score · 2=demo · 3=源 B 节拍器/鼓机）
    //      ⇒ ⚠️ looper 要**独立**成一路（⭐ 见 `evt_merge` 的第三个输入）就**没有空闲编码**了
    //      🔴 **⛔ 不许复用已有编码**：⭐ 复用它 ⇒ 曲谱的 `note_off` 会把
    //         **同轴 looper 的 voice** 一起清掉（⭐ 正是 A1 修掉的那个缺陷）
    //   ⭐ **新的编码表（3 位，用 5 个值）**：
    //      · `3'd0` = live   手弹（W3a 采集链）
    //      · `3'd1` = score  曲谱（`evt_uart_rx` 串口灌入）
    //      · `3'd2` = demo   自检和弦
    //      · `3'd3` = 源 B   节拍器 / 鼓机（⭐ 由 `top.v` 给常数，⛔ 不经过本模块）
    //      · `3'd4` = looper 回放（⭐ 新增，⭐ 在 `evt_merge` 的**第三个输入**上打标）
    //   📌 **本模块的仲裁语义一个字都没改** —— ⭐ 仍然只仲裁 live/score/demo 三路，
    //      ⭐ 只是把随事件走的**标签加宽**（⭐ 加宽对仲裁本身是**透明的**）✅
    output reg  [2:0]            evt_src_o,

    // ── ⭐ 可观测性（`K-106` 纪律：容量有限/会失效的东西必须能看见）──────────
    output reg  [15:0]           collision_cnt_o,  // ⭐ 多源同拍相撞次数（饱和）
    output reg  [15:0]           merged_cnt_o,     // ⭐ 已仲裁发出的事件数（饱和）
    output reg  [15:0]           drop_cnt_o,       // ⭐ 因溢出丢弃的条数（饱和）
    output reg                   overflow_o,       // ⭐⚠️ 溢出（sticky，复位清）
    output reg  [15:0]           live_cnt_o,       // ⭐ 转发的手弹事件数（⭐ 上板可看）
    output reg  [15:0]           score_cnt_o,      // ⭐ 转发的曲谱事件数
    output reg  [15:0]           demo_cnt_o        // ⭐ 转发的演示事件数
);

    // ── ⭐ 打包成一条记录（⚠️ 用一个向量，FIFO 索引就简单了）──────────────────
    localparam integer ENT_W = AXIS_W + PHASE_W + VEL_W + KIND_W + 1 + TIMBRE_W;
    localparam integer AX_O  = PHASE_W + VEL_W + KIND_W + 1 + TIMBRE_W;
    localparam integer IN_O  = VEL_W + KIND_W + 1 + TIMBRE_W;
    localparam integer VE_O  = KIND_W + 1 + TIMBRE_W;
    localparam integer TV_O  = TIMBRE_W;

    // ⭐⭐ 把整数参数先落到**定宽 localparam** 再参与运算
    //   🔴 **`K-91`：⛔ 绝不对 `integer` 参数做位选**（`DEPTH[15:0]` 这种）
    // Occupancy: 0..DEPTH; pointers: 0..DEPTH-1.
    // After pop, the largest three-source sum is DEPTH-1+3 = DEPTH+2.
    localparam integer CNT_W = (DEPTH < 2) ? 1 : $clog2(DEPTH + 1);
    localparam integer PTR_W = (DEPTH < 2) ? 1 : $clog2(DEPTH);
    localparam integer SUM_W = $clog2(DEPTH + 3);
    localparam [SUM_W-1:0] DEPTH_C  = DEPTH;
    localparam [PTR_W-1:0] DEPTH_M1 = DEPTH - 1;
    localparam [CNT_W-1:0] CNT_ONE = {{(CNT_W-1){1'b0}}, 1'b1};
    localparam [PTR_W-1:0] PTR_ONE = {{(PTR_W-1){1'b0}}, 1'b1};

    // ⭐⭐ 记录字段宽度（⭐ `evt_merge` 的同样手法）
    //   ⭐⭐ 2026-09-30：⭐ **2 → 3 位** —— ⭐ 理由见端口表 `evt_src_o` 那段长注释
    //     （⭐ 简言之：⭐ 2 位的 4 个值**已经用满**，而 looper 要**独立**成第 5 个源 ✅）
    //   ⚠️ **本模块只用到其中 3 个值**（live/score/demo）——
    //      ⭐ `3'd3`（节拍器·鼓机）与 `3'd4`（looper）由 `top.v` / `evt_merge` 打标，
    //      ⭐ 它们**⛔ 不经过本模块**（⭐ 所以本模块的仲裁逻辑⛔ 一行都不用改）✅
    localparam integer NW = 3;        // ⭐ 源编号宽度（5 个源 ⇒ 3 bit）
    localparam [NW-1:0] SRC_LIVE  = 3'd0;
    localparam [NW-1:0] SRC_SCORE = 3'd1;
    localparam [NW-1:0] SRC_DEMO  = 3'd2;

    // ═══════════════════════════════════════════════════════════════════════
    //  ⭐⭐ 2026-10-14：⭐ **曲谱里的【鼓】标记 ⇒ `SRC_KDRUM`** ✅
    //
    //  🔴 **为什么必须加**（⭐ 用户实测报告 ✅）：
    //     ⭐ `note_manager` 的**鼓池**只认两个来源（⭐ `note_manager.v:650` / `:1873`）：
    //        `cur_src == SRC_AUX`（⭐ 源 B = 节拍器/鼓机）
    //        `cur_src == SRC_KDRUM`（⭐ 键盘打鼓）
    //     ⚠️ 而**曲谱那一路原来打成 `SRC_SCORE`** ⇒ 🔴 **两个条件都不满足**
    //        ⇒ ⭐ **PC 灌进来的鼓被判成【乐音】⇒ 被推成音高** ✅
    //     📌 ⭐ **这正是用户听到"上到 fpga 听着怪怪的、鼓被推成音高"的根因** ✅
    //     📌 ⭐ **为什么今天才暴露**：⭐ 手弹走 `SRC_LIVE`、⭐ **键盘打鼓走 `SRC_KDRUM`**、
    //        ⭐ **鼓机走 `SRC_AUX`** ⇒ ⭐ 三条**都自带正确来源**
    //        ⇒ ⚠️ **只有"PC 灌的谱"走 `SRC_SCORE`** ⇒ ⭐ 这是**第一条**从 PC 来的鼓 ✅
    //
    //  ⭐⭐⭐ 2026-10-16：⭐ **判据从【轴号】改成【显式标志】**（⭐ 本轮核心改动）✅
    //  -----------------------------------------------------------------------
    //  🔴 **旧判据（已整个删掉）：`(score_axis_i >= 4'd12)`** ——
    //     ⚠️ 它是"⭐ **靠轴号猜是不是鼓**" ⇒ 🔴 **旋律轨用到轴 12..15 就必被读成鼓** ✅
    //     📌 **历史**：⭐ 2026-10-14 立的是 `axis == 15`；⭐ 2026-10-15（方案B）
    //        为"四件鼓各自独立 voice"放宽到 `>= 12`（⭐ 依据
    //        `files/20-代码/FPGA侧答复-鼓机多声部方案B-20261015.md`）——
    //        ⚠️ 那个做法的**代价**是"旋律轨退到 `0..11`"，🔴 而它**只是个约定**：
    //        ⭐ ESP32 侧一越界，🔴 **FPGA 侧【静默】把旋律灌进鼓池**（⭐ 用户听到的
    //        "旋律线变成鼓"正是这个）✅
    //  ✅ **新判据**：⭐ `score_is_drum_i` —— ⭐ 由 `top.v` 从帧的**保留位 `bit5`**
    //     显式解码（⭐ `ps_is_drum`），⛔ **与轴号无关** ⇒ ⭐ **轴号彻底退出判定** ✅
    //     ⭐ **机械保证**：⭐ `is_drum = 0` ⇒ ⭐ **无论轴号取 0..15 里的哪个值**
    //        本模块都给 `SRC_SCORE` ⇒ ⭐ 判据见 `tb/w3c/tb_seq_arb.sv`
    //        §"旋律绝不变鼓"（⭐ 轴 12/13/14/15 逐个断言）✅
    localparam [NW-1:0] SRC_KDRUM = 3'd5;      // ⚠️ 必须与 `note_manager.v:316` 同值

    //  ⭐⭐ 四件鼓的 `phase_inc` —— ⭐ **与 `drum_gen` 共用同一份常量**（⭐ 2026-10-16）✅
    //     🔴 **为什么必须共用**（⭐ 用户拍板的硬约束 2）：⭐ *"鼓就是鼓的发声
    //        —— 与键盘打鼓同一个 inc 表、同一个池子"* ✅
    //        ⚠️ 若 `seq_arb` 还沿用帧里的 `score_phase_inc_i`（⭐ 那是**旋律音高**），
    //           🔴 灌谱的鼓与键盘打鼓的鼓**就会是两种音色** ⇒ ⭐ 违反硬约束 ✅
    //     📌 ⭐ **单一来源**：⭐ `rtl/w3c/drum_inc_defs.vh`（⭐ `drum_gen` 也 include 它）✅
    //     ⚠️ ⭐ **必须放在 module 体内、且路径带仓库根前缀** ——
    //        🔴 `localparam` 在 module 外不是合法 Verilog-2001；
    //        🔴 而 `iverilog` 的 `` `include `` **只搜当前工作目录**（⭐ 实测）✅
    //        📌 两条依据都写在 `drum_inc_defs.vh` 的头部"用法"里 ✅
    `include "rtl/w3c/drum_inc_defs.vh"
    //  ⭐ `drum_type` 四选一：⭐ 0=Kick · 1=Snare · 2=HiHat · 3=Tom（⭐ 与 `drum_gen.inc_of` 同序）
    //     ⚠️ 纯组合 ⇒ ⭐ 综合出来是**一级 4 选 1 mux**（⭐ 约 32 LUT，⭐ 时序可接受）✅
    wire [31:0] drum_inc_by_type = (score_drum_type_i == 2'd0) ? INC_KICK  :
                                   (score_drum_type_i == 2'd1) ? INC_SNARE :
                                   (score_drum_type_i == 2'd2) ? INC_HIHAT : INC_TOM;
    //  ⭐ 真正进队列的 `inc`：⭐ **鼓 ⇒ 鼓自己的表**（⛔ 忽略帧里的音高）·
    //     ⭐ **旋律 ⇒ 帧里的 `inc` 原样透传**（⭐ 逐位不变）✅
    wire [31:0] score_inc_eff = score_is_drum_i ? drum_inc_by_type : score_phase_inc_i;
    wire [NW-1:0] score_src_w = score_is_drum_i ? SRC_KDRUM : SRC_SCORE;

    // ⭐ 事件记录 = {源编号, 轴, 相位增量, 力度, 类型}
    //   📌 ⭐ **把源编号也存进去** ⇒ ⭐ 弹出时才能知道"这条是谁的" ⇒ ⭐ 好统计
    localparam integer ENT2_W = NW + ENT_W;
    function [ENT2_W-1:0] pack_src;
        input [NW-1:0]      src;
        input [AXIS_W-1:0]  ax;
        input [PHASE_W-1:0] inc;
        input [VEL_W-1:0]   vl;
        input [KIND_W-1:0]  kd;
        input               tv;
        input [TIMBRE_W-1:0] tb;
        begin
            pack_src = {src, ax, inc, vl, kd, tv, tb};
        end
    endfunction

    // ── ⭐ FIFO 存储与指针 ─────────────────────────────────────────────────
    //   ⚠️ 用**环形缓冲**（⛔ 不是移位寄存器）：推入/弹出各只动一个指针，
    //      ⛔ 不搬数据 ⇒ 面积小、时序好（⚠️ 本项目 Fmax 余量薄）。
    reg [ENT2_W-1:0] mem [0:DEPTH-1];
    reg [CNT_W-1:0]  cnt_q;
    reg [PTR_W-1:0]  head_q;      // ⭐ 弹出位置
    reg [PTR_W-1:0]  tail_q;      // ⭐ 推入位置

    // ── ⭐ 组合：本拍能不能弹 ───────────────────────────────────────────────
    wire             pop_now  = (cnt_q != {CNT_W{1'b0}});   // ⭐ 空队列不弹（⛔ 不吐垃圾）
    wire [ENT2_W-1:0] pop_data = mem[head_q];

    // ══════════════════════════════════════════════════════════════════════
    //   ⭐⭐ 推入仲裁（⭐ 本模块的核心）
    // ══════════════════════════════════════════════════════════════════════
    //   ⭐ **两级机制**（⭐ 见文件头说明）：
    //     ① ⭐ **演示让位**：⭐ 若"有别的源在发"，⚠️ 演示**主动不参与**
    //        ⇒ ⭐ 它是自检，⛔ 不该和真演奏抢
    //     ② ⭐ **A/B 之间轮转**：⭐ 只有两路**真的都到**且**真的做过取舍**才翻面
    //
    //   📌 **为什么演示用"让位"而不是"最低优先级"**：
    //      ⚠️ 最低优先级在"手弹每拍都有"时 ⇒ 🔴 **演示永远发不出去**
    //      ⇒ ⭐ 而演示只有 **6 条**，⭐ **让它在"没人弹"时独占**才合理。
    // ══════════════════════════════════════════════════════════════════════

    // ⭐ 另两个源是否在发（⭐ 演示据此让位）
    wire others_going = live_valid_i | score_valid_i;

    // ⭐ 本拍真正参与推入的（⭐ 已应用"演示让位"）
    wire push_live  = live_valid_i;
    wire push_score = score_valid_i;
    //   ⭐ 演示：⭐ 只在"没有别的源"时才推（⭐ 让位）
    //  ⭐⭐ **2026-09-28 修（防挂音，P1-2）：`note_off` 绝不让位**
    //  🔴 原写法 `demo_valid_i & ~others_going` 会把演示和弦的 3 个 `note_off`
    //     在撞上手弹时【直接丢掉】—— ⛔ 不排队、⛔ 不计入任何计数器（违反 `K-106`）
    //     ⇒ 对应 voice 的 `gate_r` 【永久为 1】⇒ 开机自检后留下常驻音。
    //  ✅ `note_off` 是【释放】语义 ⇒ ⭐ 丢掉它只会造成【挂音】，⛔ 不会造成多音
    //     ⇒ 允许它与手弹同拍推入（FIFO 深 6，实测占用 ≤2 ⇒ 有富余）。
    //  📌 `note_on` 仍按原规则让位（⛔ 不改演示的让位语义）。
    wire demo_is_off = (demo_kind_i == 2'd1);
    wire push_demo  = demo_valid_i & (~others_going | demo_is_off);

    // ⭐ 轮转标志：0 ⇒ 手弹先；1 ⇒ 曲谱先（⭐ 只在**两者都发**时才有意义）
    reg  prio_score_r;
    wire live_first = ~prio_score_r;

    // ⭐ 本拍推几条
    //   🔴 **必须显式写位宽** —— ⚠️ `evt_merge` 踩过：`wire push_n` **隐含 1 bit**
    //      ⇒ `1+1` 被截断成 `1'b0` ⇒ 🔴 **恰好"两路同拍相撞"什么都不做**。
    wire [1:0] push_n = (push_live  ? 2'd1 : 2'd0)
                      + (push_score ? 2'd1 : 2'd0)
                      + (push_demo  ? 2'd1 : 2'd0);

    // Pop first; zero-extend BEFORE adding so overflow cannot wrap away.
    wire [CNT_W-1:0] cnt_after_pop = pop_now ? (cnt_q - CNT_ONE) : cnt_q;
    wire [SUM_W-1:0] cnt_next = {{(SUM_W-CNT_W){1'b0}}, cnt_after_pop}
                             + {{(SUM_W-2){1'b0}}, push_n};
    wire            will_overflow = (cnt_next > DEPTH_C);

    // Add at SUM_W, wrap at full precision, then narrow the valid pointer.
    //
    //  🔴🔴 2026-10-17 修（`D7`，只读审计发现）：⭐ 原来连做 **3 次**条件减法
    //     ```verilog
    //     if (r >= DEPTH_C) r = r - DEPTH_C;
    //     if (r >= DEPTH_C) r = r - DEPTH_C;
    //     if (r >= DEPTH_C) r = r - DEPTH_C;
    //     ```
    //  🔴 **第 2、3 次在 DEPTH >= 3 时【不可达】**（⭐ 可证）：
    //     · `t = tail_q ∈ [0, DEPTH-1]`（⭐ 指针由本函数自己维护并回绕）
    //     · `n ≤ 3`（⭐ `n` 是 2 位）
    //     ⇒ `r = t + n ≤ DEPTH - 1 + 3 = DEPTH + 2`
    //     ⇒ ⭐ **一次减法后 `r ≤ 2`**，而 `DEPTH = 6 >= 3` ⇒ ⭐ `r < DEPTH` 恒成立
    //     ⇒ 🔴 后两次判断**永远为假** ⇒ ⭐ **死逻辑**，而它正是本模块最长组合链的一段
    //        （⭐ 4 位 `>=` 比较 ＋ 4 位减，串行两次 ≈ **4 级 LUT**）
    //  ✅ **修法**：⭐ 只留**一次**条件减法（⭐ 对 `DEPTH >= 3` 与旧行为**逐位等价**）
    //     📌 自检：⭐ 见下方 `initial`（⛔ 若有人把 `DEPTH` 调到 < 3 会报警）
    //     📌 判据：⭐ `tb/w3c/tb_seq_arb.sv` 的 tail 回绕值必须逐位不变
    function [PTR_W-1:0] tail_plus;
        input [PTR_W-1:0] t;
        input [1:0] n;
        reg [SUM_W-1:0] r;
        begin
            r = {{(SUM_W-PTR_W){1'b0}}, t} + {{(SUM_W-2){1'b0}}, n};
            if (r >= DEPTH_C) r = r - DEPTH_C;
            tail_plus = r[PTR_W-1:0];
        end
    endfunction

    wire [PTR_W-1:0] tail_1 = tail_plus(tail_q, 2'd1);
    wire [PTR_W-1:0] tail_2 = tail_plus(tail_q, 2'd2);
    //  ⚠️ `tail_3` 已删（`D6`）：⭐ 它被计算但**从未被引用**
    //     （⭐ 3 源同拍只用 `mem[tail_q]`/`[tail_1]`/`[tail_2]`）⇒ ⭐ 死逻辑 ✅

    // ⭐ 弹出那条属于哪个源（⭐ 统计用）
    wire [NW-1:0] pop_src = pop_data[ENT_W +: NW];

    // ══════════════════════════════════════════════════════════════════════
    //   ⭐⭐ 主时序
    // ══════════════════════════════════════════════════════════════════════
    always @(posedge clk_i) begin
        if (!rst_n_i) begin
            evt_valid_o     <= 1'b0;
            evt_axis_o      <= {AXIS_W{1'b0}};
            //  🔴🔴 2026-10-16（`CALIBRATE-R`）：⭐ **`evt_up_axis_o` 必须【一起】复位** ✅
            //     ⚠️ 它是 2026-10-16 新加的端口，⛔ **当时漏在复位块之外** ⇒
            //        🔴 **它在本模块里【唯一的赋值语句】在 `pop_now` 分支内**
            //           （⭐ `seq_arb.v` 的 `evt_up_axis_o <= ...`）✅
            //        ⇒ ⭐ 于是**复位后的第一个 `pop_now` 之前**，它一直停在 `x`
            //        ⇒ 🔴 **X 传播**（⭐ 顺着 `sa_up_axis` 进 `evt_upstream` 的 FIFO，
            //           ⚠️ 并出现在**第一帧**的 `byte[7]` 低半字节上 ✅）✅
            //     📌 ⭐ **这正是本文件 A8 纪律（⛔ 不许留 X）的直接违反** ——
            //        ⚠️ 而 `tb_top_upstream_timbre` 的**第一条帧**恰好踩在这一段 ✅
            //     📌 ⭐ 其余输出（`evt_axis_o`/`evt_kind_o`/`evt_src_o`…）都在复位块里
            //        ⇒ ⭐ 本行就是补齐同一条纪律，⛔ 不新增任何逻辑 ✅
            evt_up_axis_o   <= {AXIS_W{1'b0}};
            evt_phase_inc_o <= {PHASE_W{1'b0}};
            evt_velocity_o  <= {VEL_W{1'b0}};
            evt_kind_o      <= {KIND_W{1'b0}};
            evt_timbre_valid_o <= 1'b0;
            evt_timbre_o    <= {TIMBRE_W{1'b0}};
            evt_src_o       <= 3'd0;          // ⭐ A1：来源标记也复位（⛔ 不留 X）
            cnt_q           <= {CNT_W{1'b0}};
            head_q          <= {PTR_W{1'b0}};
            tail_q          <= {PTR_W{1'b0}};
            prio_score_r    <= 1'b0;
            collision_cnt_o <= 16'd0;
            merged_cnt_o    <= 16'd0;
            drop_cnt_o      <= 16'd0;
            overflow_o      <= 1'b0;
            live_cnt_o      <= 16'd0;
            score_cnt_o     <= 16'd0;
            demo_cnt_o      <= 16'd0;
        end else begin
            // ⭐ 默认：脉冲类输出每拍清零 ⇒ 严格单周期
            evt_valid_o <= 1'b0;

            // ══ ① 弹出并输出（⭐ 弹出优先，先腾位置）════════════════════════
            if (pop_now) begin
                evt_valid_o     <= 1'b1;
                //  ⭐ 下行定位键：⭐ **原样透传**（⭐ 逐位恢复改动前，⭐ 见端口注释的 P0-1/P0-2 ✅）
                evt_axis_o      <= pop_data[AX_O +: AXIS_W];
                //  ⭐⭐ 上行专用"鼓标记"（⭐ 只给上行帧，⛔ 不碰下行 ✅）
                //     · 鼓（`pop_src == SRC_KDRUM`）⇒ 回传 `drum_type`（⭐ 存在 timbre 字段 ✅）
                //     · 其余一切来源 ⇒ 回传 **0** ⇒ ⭐ 上行帧里 `axis != 0` 等价于"这是鼓" ✅
                //     📌 ⭐ 为什么⛔ 不能用 `score_is_drum_i`：⭐ `pop_now` 弹出的可能是
                //        几拍前的事件 ⇒ 用当前下行帧的标志会【错配到别的音上】✅
                evt_up_axis_o   <= (pop_src == SRC_KDRUM)
                                    ? {2'b0, pop_data[0 +: TIMBRE_W]}
                                    : {AXIS_W{1'b0}};
                evt_phase_inc_o <= pop_data[IN_O +: PHASE_W];
                evt_velocity_o  <= pop_data[VE_O +: VEL_W];
                evt_kind_o      <= pop_data[TV_O + 1 +: KIND_W];
                evt_timbre_valid_o <= pop_data[TV_O +: 1];
                evt_timbre_o    <= pop_data[0 +: TIMBRE_W];
                // ⭐ A1：⭐ 来源标记与**本拍弹出的这条**同时输出（⭐ 时序 = `evt_valid_o`）
                evt_src_o       <= pop_src;
                head_q          <= (head_q == DEPTH_M1) ? {PTR_W{1'b0}} : (head_q + PTR_ONE);
                merged_cnt_o    <= (merged_cnt_o == 16'hFFFF) ? merged_cnt_o
                                                              : (merged_cnt_o + 16'd1);
                // ⭐ 按源分别统计（⭐ 上板时"谁在发"一眼可见）
                if (pop_src == SRC_LIVE)
                    live_cnt_o  <= (live_cnt_o  == 16'hFFFF) ? live_cnt_o
                                                             : (live_cnt_o  + 16'd1);
                //  ⭐⭐ 2026-10-14：⭐ **`SRC_KDRUM` 也算【曲谱】统计** ✅
                //     🔴 **为什么**：⭐ 曲谱里的鼓（⭐ 现在由 **`score_is_drum_i`** 判定，
                //        ⚠️ 2026-10-16 之前是 `axis>=12` —— ⭐ 判定依据已改成显式标志，
                //        ⭐ 见上面 `score_src_w` 的长注释 ✅）
                //        ⇒ ⭐ 它被打成 `SRC_KDRUM`（⭐ 好让 `note_manager` 推进**鼓池**）✅
                //     ⚠️ 若不并进来 ⇒ 🔴 鼓事件会**掉进下面的 `else` ⇒ 被算成 `demo_cnt`** ✅
                else if ((pop_src == SRC_SCORE) || (pop_src == SRC_KDRUM))
                    score_cnt_o <= (score_cnt_o == 16'hFFFF) ? score_cnt_o
                                                             : (score_cnt_o + 16'd1);
                else
                    demo_cnt_o  <= (demo_cnt_o  == 16'hFFFF) ? demo_cnt_o
                                                             : (demo_cnt_o  + 16'd1);
            end

            // ══ ② 推入（⚠️ 只有装得下才推；⛔ 装不下要【看得见】）════════════
            if (push_n != 2'd0) begin
                if (!will_overflow) begin
                    // ⭐ 按"谁先"定推入顺序（⭐ FIFO 保序 ⇒ 先推的先出）
                    //   🔴 **为什么顺序重要**：⭐ 手弹优先级最高 ⇒ ⭐ 它应当**先出队**
                    //      ⚠️ 但**不能永远先**（⭐ 那会饿死曲谱）⇒ ⭐ 轮转
                    if (push_live && push_score && push_demo) begin
                        // ⭐ 三条全到（⚠️ 极罕见：演示只在"没别的"时才推 ⇒ 此路实际不可达，
                        //    ⭐ 但**保留** ⇒ ⭐ 不给"将来改让位规则"留坑）
                        if (live_first) begin
                            mem[tail_q] <= pack_src(SRC_LIVE,  live_axis_i,  live_phase_inc_i,  live_velocity_i,  live_kind_i,  live_timbre_valid_i,  live_timbre_i);
                            mem[tail_1] <= pack_src(score_src_w, score_axis_i, score_inc_eff, score_velocity_i, score_kind_i, score_timbre_valid_i, score_timbre_i);
                            mem[tail_2] <= pack_src(SRC_DEMO,  demo_axis_i,  demo_phase_inc_i,  demo_velocity_i,  demo_kind_i,  demo_timbre_valid_i,  demo_timbre_i);
                        end else begin
                            mem[tail_q] <= pack_src(score_src_w, score_axis_i, score_inc_eff, score_velocity_i, score_kind_i, score_timbre_valid_i, score_timbre_i);
                            mem[tail_1] <= pack_src(SRC_LIVE,  live_axis_i,  live_phase_inc_i,  live_velocity_i,  live_kind_i,  live_timbre_valid_i,  live_timbre_i);
                            mem[tail_2] <= pack_src(SRC_DEMO,  demo_axis_i,  demo_phase_inc_i,  demo_velocity_i,  demo_kind_i,  demo_timbre_valid_i,  demo_timbre_i);
                        end
                    end else if (push_live && push_score) begin
                        // ⭐ 手弹 + 曲谱同拍（⭐ **最要紧的一种**：⭐ 必须两条都发）
                        if (live_first) begin
                            mem[tail_q] <= pack_src(SRC_LIVE,  live_axis_i,  live_phase_inc_i,  live_velocity_i,  live_kind_i,  live_timbre_valid_i,  live_timbre_i);
                            mem[tail_1] <= pack_src(score_src_w, score_axis_i, score_inc_eff, score_velocity_i, score_kind_i, score_timbre_valid_i, score_timbre_i);
                        end else begin
                            mem[tail_q] <= pack_src(score_src_w, score_axis_i, score_inc_eff, score_velocity_i, score_kind_i, score_timbre_valid_i, score_timbre_i);
                            mem[tail_1] <= pack_src(SRC_LIVE,  live_axis_i,  live_phase_inc_i,  live_velocity_i,  live_kind_i,  live_timbre_valid_i,  live_timbre_i);
                        end
                    end else if (push_live && push_demo) begin
                        mem[tail_q] <= pack_src(SRC_LIVE, live_axis_i, live_phase_inc_i, live_velocity_i, live_kind_i, live_timbre_valid_i, live_timbre_i);
                        mem[tail_1] <= pack_src(SRC_DEMO, demo_axis_i, demo_phase_inc_i, demo_velocity_i, demo_kind_i, demo_timbre_valid_i, demo_timbre_i);
                    end else if (push_score && push_demo) begin
                        mem[tail_q] <= pack_src(score_src_w, score_axis_i, score_inc_eff, score_velocity_i, score_kind_i, score_timbre_valid_i, score_timbre_i);
                        mem[tail_1] <= pack_src(SRC_DEMO,  demo_axis_i,  demo_phase_inc_i,  demo_velocity_i,  demo_kind_i,  demo_timbre_valid_i,  demo_timbre_i);
                    end else if (push_live) begin
                        mem[tail_q] <= pack_src(SRC_LIVE, live_axis_i, live_phase_inc_i, live_velocity_i, live_kind_i, live_timbre_valid_i, live_timbre_i);
                    end else if (push_score) begin
                        mem[tail_q] <= pack_src(score_src_w, score_axis_i, score_inc_eff, score_velocity_i, score_kind_i, score_timbre_valid_i, score_timbre_i);
                    end else begin
                        mem[tail_q] <= pack_src(SRC_DEMO, demo_axis_i, demo_phase_inc_i, demo_velocity_i, demo_kind_i, demo_timbre_valid_i, demo_timbre_i);
                    end

                    // ⭐ 推进 tail（按实际推入条数）
                    tail_q <= tail_plus(tail_q, push_n);
                    cnt_q  <= cnt_next[CNT_W-1:0];
                end else begin
                    // 🔴 **溢出**：⭐ 丢弃并**记数 + 置 sticky 标志**（⛔ 不静默）
                    overflow_o <= 1'b1;
                    //  ⭐⭐ 2026-10-09（`P0-16`）：⭐ **饱和判据必须升到 17 位** ✅
                    //   🔴 **原缺陷**：⭐ 与 `evt_merge.v:363` **同一处写法错误** ——
                    //      ⚠️ `drop_cnt_o`(16) `+` `push_n`(2) ⇒ ⭐ **和自定宽度 = 16 位**
                    //      ⇒ 🔴 `x > 16'hFFFF` **恒为假** ⇒ ⭐ 饱和分支是死代码 ⇒ **计数器回绕** ✅
                    //   ⭐ **修法**：⭐ 零扩展到 17 位再比（⭐ 详见 `evt_merge.v` 同处的说明）✅
                    if (drop_cnt_o != 16'hFFFF)
                        drop_cnt_o <= ({1'b0, drop_cnt_o} + push_n > 17'h0FFFF)
                                      ? 16'hFFFF : (drop_cnt_o + push_n);
                    // ⚠️ **本拍的弹出必须照样记账**（⭐ `evt_merge` 踩过的坑：
                    //    原来 overflow 分支里完全没写 `cnt_q` ⇒ `cnt_q` 永远 > 0
                    //    ⇒ `pop_now` 恒真 ⇒ 🔴 `evt_valid_o` 一直挂着、不再单周期）
                    cnt_q <= cnt_after_pop;
                end
            end else if (pop_now) begin
                // ⭐ 只弹不推：更新计数（tail 不动）
                cnt_q <= cnt_after_pop;
            end

            // ══ ③ 统计与优先级轮转 ══════════════════════════════════════════
            // ⭐ "相撞"= 本拍有 ≥2 个源**真正参与推入**（⭐ 演示让位后不算）
            if ((push_live && push_score) || (push_live && push_demo)
                || (push_score && push_demo)) begin
                collision_cnt_o <= (collision_cnt_o == 16'hFFFF) ? collision_cnt_o
                                                                 : (collision_cnt_o + 16'd1);
            end
            // ⭐ **只有 A/B 真的都到才翻面**（⚠️ 单源来时翻面没有意义 ⇒
            //    ⭐ 且会让"固定优先级"退化）
            if (push_live && push_score) begin
                prio_score_r <= ~prio_score_r;
            end
        end
    end

endmodule

`default_nettype wire
