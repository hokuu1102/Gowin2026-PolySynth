`timescale 1ns/1ps
// ─────────────────────────────────────────────────────────────────────────────
// oscillator_bank.v · 64 路独立振荡器组（W3b · `T55` 去桩实装）
//
// ⭐ 为什么这个模块是「评分主体」（`K-83`/`K-84`）：
//   赛题要求**吞吐量 = 同时可闻的独立振荡器数 × 采样率**。
//   ⇒ ⭐ **每个振荡器必须有自己的相位累加器**（⛔ 不能共用、⛔ 不能用 DDS IP），
//      评委**翻代码时要能数出 64 份相位寄存器**。
//   · `POLY_TARGET=32` × `OSC_PER_VOICE=2` = **64 lane**
//   · 每个 voice 的 2 个振荡器用于**失谐叠加**（同 voice 内两个 lane 独立相位）
//
// ⭐ 为什么不用 Gowin DDS IP（`K-83` 定量复核）：
//   ⚠️ **DDS IP 每实例自带 ROM 且加密不可合并** ⇒ 64 实例最省配置也要吃
//      **97 % BSRAM**；⭐ **自己写只要 131 kbit（共享波表）**。
//
// ⭐ 架构（TDM 共享波表 —— 这是本模块的核心设计）
//
//   ┌─ 64 个【独立】相位累加器（generate 展开，每人一份寄存器）─────────┐
//   │   sample_tick_i 到来时： addr_q[lane] ← phase[lane][31:22]（本帧地址）│
//   │                          phase[lane] += inc[lane]                    │
//   └──────────────────────────────┬───────────────────────────────────────┘
//                                  ▼
//   ┌─ 1 个【共享】pROM（1024×16，Bypass 模式 = 1 级同步读）───────────────┐
//   │   TDM 依次送 64 个地址 ⇒ 64 拍取回 64 个样本                         │
//   └──────────────────────────────┬───────────────────────────────────────┘
//                                  ▼
//   osc_sample_bus_o（64×16 bit，lane i = bus[i*16 +: 16]）
//   osc_valid_o（全部取回后 1 拍脉冲）
//   📌 ⭐ **pROM 规格（⭐ 以代码为准）**：⭐ `WT_DEPTH = 1024` ⇒ `AW = $clog2(1024) = 10`
//      ⇒ ⭐ 地址取 `phase[lane][31:22]`（⭐ `ADDR_MSB:ADDR_LSB`，见本文件的 `localparam ADDR_MSB`/`ADDR_LSB` 与 `addr_q` 赋值）
//      ⚠️ 旧注释写"512×16 / `AW = 9` / `phase[lane][31:23]`" —— 🔴 **已作废**
//
//   ⭐ **为什么 TDM 是安全的**：每采样帧有 **1024** 个 clk（`CLK_PER_SAMPLE`），
//      而 TDM 只需 **LANES+2 = 66 拍** ⇒ ⭐ 余量 15×，
//      且**拍数固定**（⛔ 无变长搜索）⇒ 满足 `A6`（帧内截止）的确定性要求。
//
// ⚠️ 本模块**不做**的事（各有归属，⛔ 不要在这里加）：
//   · **包络乘法 / 混音** → `tdm_render_mixer`（`T56`）
//   · **voice 分配 / 抢占** → `note_manager`（`T54`）
//   · **ADSR** → `envelope_bank` / `adsr`（队友已落地）
//
// ⛔ 纪律（本项目血泪）：
//   · ⭐ **Verilog-2001 语法**（`K-91`：Gowin 按 Verilog-2001 编译 `.sv`，
//     用 SV 专有构造 `N'()`/`logic`/`always_ff` ⇒ **整个模块被丢弃**，而**仿真全绿**）
//   · ⭐⭐ **组合逻辑用 `assign` + `generate`，⛔ 不用 `always @(*)`**
//     （`K-93`/经验库 `L67`：参数取默认值时"全是常量"的组合块
//      **没有任何敏感信号 ⇒ 仿真器从不执行它**，而综合器却正常折叠
//      ⇒ **两个前端行为不一致**。本模块所有掩码/选择都走连续赋值。）
//   · ⛔ 不用 PLL、不派生时钟；`sample_tick_i` 只是**时钟使能**（冻结表 §〇 约定 1）
//   · ⛔ 不对 `integer` 参数做位选（`K-91` 顺带发现）
// ─────────────────────────────────────────────────────────────────────────────
`default_nettype none

module oscillator_bank #(
    parameter integer POLY_TARGET   = 32,
    parameter integer OSC_PER_VOICE = 2,
    parameter integer PHASE_W       = 32,
    parameter integer OSC_SAMPLE_W  = 16,
    // ⭐ `K-86`：四大件（BASS/GUITAR/PIANO/PAD）+ Looper 一层一件乐器 ⇒ 需 ≥3 种
    parameter integer TIMBRE_N      = 4,
    parameter integer TIMBRE_W      = 2,
    parameter integer WT_DEPTH      = 1024,
    parameter integer WT_W          = 16,
//  ⭐⭐ 2026-09-29 修 bug②：⭐ **力度是否参与音色（soft/hard 波表插值）**
//
//   ⭐ **0（默认）= 关** ⇒ ⭐ **波表固定用 `rom_soft`**（⭐ 音色**只由 `timbre` 决定**）✅
//   ⭐ 1 = 旧行为（⭐ `velocity = 0` → soft · `velocity = 255` → hard ✅）
//
//   🔴 **为什么默认关（上板实测 + 用户裁定）**：
//      ⭐ 位置式力度 `vel_upd` 把 `vel_r` 推到 **255** ⇒ ⭐ 按到底变成**纯三角波**
//      ⇒ 🔴 用户听到"**音色不同的电子音**"（⭐ 幅度趋势不变、只是音色变了）✅
//      ⭐ **实测谱形**（100 ms / 100 kHz 捕获，C3）：
//         h1 = 0 dB · **h3 = −18.9 dB** · **h4 = −46.5 dB（深零点）** · h5 = −21.8 dB
//         ⇒ ⭐ 三角波的 h3 理论值 = 1/9 = **−19.1 dB** ⇒ ⭐ **就是三角波** ✅
//      ⭐ 用户裁定（2026-09-29）：⭐ **"不应该改变音色"** ✅ ⇒ ⭐ **固定 `rom_soft`** ✅
//
//   📌 **保留参数的两个理由**：⭐ ① 可回退 ✅ ② ⭐ **后续还会改波表**
//      ⇒ ⭐ 改波表时**不用再动这一路** ✅
//   ⭐ **副作用（好的）**：⭐ `VELOCITY_BLEND_EN = 0` 是**编译期常量** ⇒
//      ⭐ 力度插值那一路被**综合器整块折叠掉** ⇒ ⭐ 省一个 TDM 乘法器 ✅
//  ⭐⭐ 2026-09-29 合并（⭐ 队友 `codex/t31b-final-6db-s2`）：⭐ **参数改名 + 语义更明确** ✅
//   · ⭐ `VELOCITY_BLEND_EN`：⭐ 0 = **力度【不】改音色**（⭐ 默认 ✅）· 1 = 旧行为（⭐ 力度插值 soft/hard ✅）
//   · ⭐ `FIXED_BLEND_Q`：⭐ 仅当上面为 0 时生效 —— ⭐ **Q0.8 固定音色**（⭐ 0 = soft · 256 = hard ✅）
//   🔴 为什么默认固定：⭐ 满行程时旧的"力度→音色"会把波形推到 **200/256 的 hard 成分**
//      ⇒ ⭐ 每个音色都变成粗糙持续音 ＋ ⭐ 和弦里谐波堆积（⭐ 不可用 ✅）
parameter integer VELOCITY_BLEND_EN = 0,
parameter integer FIXED_BLEND_Q     = 0,
    // ⚠️ FM **未实装**（`A2c`：先留接口、后加；且 FM **不计入吞吐量**）
    parameter integer ENABLE_FM     = 0,
    // ⭐ 颤音参考相位增量（Q 单位：`f_out = inc × fs / 2^32`）
    //    A4 = 440 Hz ⇒ 440 × 2^32 / 48828.125 ≈ 38_700_000
    parameter integer VIB_REF_INC   = 38_700_000,
    // ⭐ 调试观测选哪个 lane（冻结表 §2.6：`phase_acc_dbg_o` 是"**选定 lane** 调试"）
    parameter integer DBG_LANE      = 0,
    // ⭐⭐ **失谐量**（⭐ 2026-09-26 新增，⭐ 修"假 unison"）
    //   · 0 => ⚠️ **不失谐**（⭐ 两个 lane 严格同相 —— 🔴 **旧的错误行为**）
    //   · 1 => ⭐ **失谐**（⭐ **默认** —— 第二个 osc 的频率偏移 `DETUNE_SH` 位移）
    //
    //   🔴🔴 **为什么必须加**（⭐ 2026-09-26 上板 + 源码对照定位）：
    //      ⚠️ 原来两个 lane 拿的是**同一个** `base_phase_inc_i`，
    //         ⭐ 且复位后 `phase_q` **同为 0**
    //         ⇒ 🔴 **两个 lane 永远同频同相** ⇒ ⭐ `lane0 + lane1 = 2 × lane0`
    //      🔴 **后果**：⭐ **幅度严格 ×2（6 dB 白丢）**、⭐ **零音色收益**、
    //         🔴 **且叠加行为不可控 ⇒ gain 没有唯一解**（⭐ 这是反复调 gain 失败的根因）。
    //      📌 **注释一直声称"失谐叠加"** ⇒ 🔴 **该功能【从未实现】**。
    //
    //   ⭐⭐ **对照开源实现（⭐ 都是硬件验证过的）**：
    //      · [xls32](https://github.com/kazunori279/xls32-fpga-synth) ⇒ ⭐ **"detuned dual"**
    //      · [Noaidi](https://github.com/Thorwegian/noaidi-fpga-synth) ⇒ ⭐ **"8 detuned unison"**
    //      ⇒ ⭐ **两者都靠失谐** ⇒ ⭐ **叠加是√N 而非 N** ⇒ ⭐ **幅度自然受控**。
    //
    //   ⭐ **实现手法（⭐ 零 DSP 开销）**：
    //      ⭐ 第二个 osc 的增量 = `base_inc + (base_inc>>DETUNE_SH)`
    //      📌 **用【移位加法】而⛔ 不用乘法器** —— ⚠️ 64 lane 各配一个乘法器
    //         会吃掉 64 个 DSP（⭐ 60K 只有 118 个）⇒ 🔴 不可接受。
    parameter integer DETUNE_ON     = 1,
    //   ⭐ 失谐位移量：⭐ **模块默认 `8`（偏移 `1/256 ≈ 0.391%` ⇒ 约 6.7 cents）**；
    //      ⭐⭐ **本设计顶层传 `9`**（⭐ `top.v` 的 `parameter integer DETUNE_SH = 9` 命名参数覆盖）
    //      ⇒ ⭐ **交付偏移 = `1/512 ≈ 0.195% ≈ 3.38 cents`**、⭐ 交付拍频周期 `T = 512/f`
    //      📌 **cents 的依据**：⭐ 常见"温和 detune"区间（⭐ 5~15 cents）
    //         ⭐ 太小（<3 cents）⇒ 拍频太慢（⭐ 十几秒才一拍）⇒ ⭐ 听不出厚度
    //         ⚠️ 太大（>20 cents）⇒ ⭐ 听起来"走音"（⭐ 而不是"厚"）
    //      ⚠️ 本项目 16 轴磁轴 ⇒ ⭐ 用户要"能听出和弦"；⭐ 顶层取 `9`（3.38 cents、`T = 512/f`）
    //         ⇒ ⭐ 更"厚"而⛔ 不走音
    parameter integer DETUNE_SH     = 8,
// ═════════════════════════════════════════════════════════════════════════════
//  ⭐⭐ 2026-09-30 新增（鼓机音高包络 · 阶段 2b）：⭐ **鼓 voice 的向下扫频** ✅
//
//  🔴 **为什么必须加**（⭐ 用户原始反馈："鼓机听起来像**音高不同的节拍器**"）：
//     · ⭐ 阶段 2a 已经把鼓 voice 切到**宽带噪声表** ⇒ ⭐ 不再是"纯音嘀嗒" ✅
//     · 🔴 但 4 件乐器**仍然共用一个 `AXIS_ID`**、⭐ 事件里**没有乐器号** ⇒
//        ⭐ 每件鼓的**音高是恒定的** ⇒ 🔴 底鼓听起来是"**一声低频噪声**"，
//        ⛔ 不是"咚" ✅
//     · ⭐ **真实底鼓** = 低频正弦 ＋ ⭐ **快速下滑的音高包络**
//        （⭐ ~100 Hz → ~50 Hz / **50~80 ms** ✅）＋ ⭐ 击槌的"咔"（click ✅）
//        ⭐ 嗵鼓同理（⭐ 滑得浅一些 ⇒ ⭐ 保留音高感 ✅）
//     📌 本阶段**只做音高包络**（⭐ click 见下方 `DRUM_CLICK_*` 的说明 —— **未实装** ✅）
//
//  ⭐ **做法**：⭐ 给鼓 lane 的**相位增量**加一个**按采样拍指数衰减**的偏移
//     ⇒ ⭐ 起音那一瞬间**瞬时频率最高** ⇒ ⭐ 之后指数回落
//     ⇒ ⭐ 稳态**精确等于** `PHASE_INC`（⭐ 偏移衰减到 0 ✅）
//
//  🔴 **时序纪律（⭐ 本设计刚在 43.66 MHz 上挂掉，⭐ 队友在修）**：
//     · ⛔ **无乘法器**、⛔ **无除法器**、⛔ **无 DSP**（⭐ 只移位 ＋ 加法 ✅）
//     · ⛔ **不给相位通路加长组合链** —— ⭐ 偏移来自**寄存器** `sweep_q`
//        ⇒ ⭐ 相位通路只多 **1 级 32 位加法器**（⭐ 见报告 ✅）
//     · ⭐ 衰减是**自反馈寄存器**（⭐ 与相位通路**并行**，⛔ 不在关键路径上 ✅）
//
//  📌 **`DRUM_PITCH_ENV_EN = 0` 是编译期常量** ⇒ ⭐ 综合器把整块扫频逻辑
//     **折叠掉**（⭐ 与 `VELOCITY_BLEND_EN = 0` 同一套路 ✅）
//     ⇒ ⭐ 它同时是**非空洞性**开关：⭐ 置 0 跑 `tb_drum_pitch_env` ⇒ **判据必红** ✅
// ═════════════════════════════════════════════════════════════════════════════
    //  ⭐ 总开关：⭐ 1 = 开（⭐ 默认 ✅）· ⭐ 0 = 关（⭐ 非空洞性用 ✅）
    parameter integer DRUM_PITCH_ENV_EN = 1,
    //  ⭐ **衰减时间常数**：⭐ `τ = 2^DRUM_SWEEP_SH` 个采样拍
    //     ⭐ `10` ⇒ τ = 1024 拍 · ⭐ @48.828 kHz = **21 ms**
    //     ⇒ ⭐ 3τ ≈ 63 ms 落到 **5%** ⇒ ⭐ 正好落在"**50~80 ms 扫完**"区间 ✅
    //     📌 **口径**：⭐ 每拍 `sweep <= sweep - (sweep >> SH) - 1`（⭐ 指数 ✅）
    parameter integer DRUM_SWEEP_SH     = 10,
    //  ⭐ **偏移定标**：⭐ `sweep_off = sweep_q << DRUM_SWEEP_LSB_SH`
    //     ⭐ `8` ⇒ ⭐ `sweep_q` **只要 16 位**（⭐ 省 1024 个 FF —— 64 lane ✅）
    //     ⚠️ 代价：⭐ 扫频**最低分辨** = 256（⭐ 对 `INC_KICK` 是 **0.004%** ⇒ 可忽略 ✅）
    parameter integer DRUM_SWEEP_LSB_SH = 8,
    //  ⭐ **每件鼓的扫频深度**：⭐ `深度 = base_inc >> SH`（⭐ SH 越大越浅 ✅）
    //     · ⭐ **底鼓** `SH = 0` ⇒ ⭐ 深度 = **100% 标称** ⇒ ⭐ 起音 **2× 频率**
    //       （⭐ ≈146 Hz → 73 Hz ⇒ ⭐ 与"~100→50 Hz"的**比例**一致 ✅）
    //     · ⭐ **嗵鼓** `SH = 2` ⇒ ⭐ 深度 = **25%** ⇒ ⭐ 起音 **1.25×**
    //       （⭐ 只"轻轻一滑" ⇒ ⭐ **保留音高感** —— ⭐ 那正是嗵鼓存在的意义 ✅）
    //     · ⭐ **军鼓 / 踩镲**：⭐ **深度 0（不扫）** ✅
    //       ⭐ 理由：⭐ 它们靠**噪声的宽带**辨识（⛔ 不靠音高）；⭐ 扫频只会让它"糊"；
    //          ⭐ 军鼓的"啪"来自**包络**（`perc_env_bank`）⛔ 不是音高 ✅
    parameter integer DRUM_KICK_SWEEP_SH = 0,
    parameter integer DRUM_TOM_SWEEP_SH  = 2,
    //  ⭐ **"这是哪件鼓"的判据 = 用 `base_inc` 就地分档** ✅
    //     ⚠️ **为什么⛔ 不加一根"乐器号"总线**：⭐ 4 件乐器**共用 `AXIS_ID`**、
    //        ⭐ 事件格式里**没有乐器字段**（⭐ 它本来就是靠 `PHASE_INC` 区分 ✅）
    //        ⇒ ⭐ 想加就得改**冻结的 64 bit 事件格式** ⇒ 🔴 整条通路返工 ✅
    //        ⇒ ⭐ **音高本身就是乐器身份** ⇒ ⭐ 就地分档是**最小改动** ✅
    //     ⭐ 分档点（⭐ 相位增量 · ⭐ `inc = f × 2^32 / 48828.125 = f × 87961`）：
    //        · ⭐ `5_368_709` ≈ 60 Hz（底鼓）· ⭐ `17_895_697` ≈ 200 Hz（嗵鼓）
    //        · ⭐ `17_179_869` ≈ 195 Hz（军鼓）· ⭐ `171_798_691` ≈ 1953 Hz（踩镲）
    //     ⇒ ⭐ 两道门限取在**两两之间**（⭐ 离两边都 ≥ 30% 余量 ⇒ ⭐ 不怕微调音高 ✅）
    parameter integer DRUM_KICK_MAX     = 10_000_000,   // ⭐ ≈114 Hz（底鼓 / 嗵鼓 之间）
    parameter integer DRUM_TOM_MAX      = 15_000_000,   // ⭐ ≈171 Hz（嗵鼓 / 军鼓 之间）
    //  ⭐ **click（击槌的"咔"）—— ⚠️ 本阶段【未实装】**
    //     ⭐ 留参数是为了**口径显式**（⭐ `K-106`：⛔ 不许静默失效 ✅）：
    //     🔴 为什么不做：⭐ click 要"起音几个采样拍**额外加高频**"
    //        ⇒ ⚠️ 要么**再选一张表**（⭐ 改 TDM 的选表 mux ＋ 标签 ✅），
    //        ⚠️ 要么**在样本上加脉冲**（⭐ 动 `tdm_render_mixer` 的饱和口径 ✅）
    //        ⇒ 🔴 **两者都会碰刚挂掉的那条时序路径** ⇒ ⭐ 本阶段**只做音高包络**，
    //        ⭐ 把时序余量留给队友 ✅（⭐ 见报告"未做项" ✅）
    parameter integer DRUM_CLICK_EN     = 0,
    //  ⭐⭐ 2026-10-08（`A3` 正确修法）：⭐ **鼓分类是否由上层给**（⭐ 0 = 本模块自己比 ✅）
    //   ⭐ **语义**：
    //      · `0`（⭐ 默认）⇒ ⭐ **本模块内部**用 `bv`（⭐ 变调后的增量）与常量阈值比 ——
    //         ⭐ **老行为** ⇒ ⭐ 所有**直接例化本模块的 tb 一个都不用改** ✅
    //      · `1` ⇒ ⭐ **改用 `drum_cls_i`**（⭐ 由 `note_manager` 在**提交那一刻**算好 ✅）
    //         ⇒ ⭐ **零窗口**（⭐ 不再受 `phase_tr` 轮转 32 拍的影响）✅
    //         ＋ ⭐ **省掉那 64 个比较器**（⭐ 2×32 个 32 位常量比较器 ≈ **640 LUT**）✅
    //   📌 ⭐ **为什么用参数门控**（⭐ 而不是 Z-safe 回退）：⭐ 参数是**编译期常量**
    //      ⇒ ⭐ `1` 时那 64 个比较器**根本不参与综合** ⇒ ⭐ **净省 ~500 LUT** ✅
    //      （⭐ 而 Z-safe 回退会把比较器留着 ⇒ 🔴 净收益归零 —— ⭐ 那正是本修法第一版失败的原因 ✅）
    //   📌 `top.v` 传 **1**（⭐ 唯一的生产例化 ✅）；⭐ 所有 tb 用默认 **0** ✅
    parameter integer DRUM_CLS_EXT      = 0,
    //  ⭐⭐ 2026-10-17：⭐ **osc 采样"读 mux"改 BSRAM**（⭐ PnR 布线卡死 ⇒ 腾 LUT）✅
    //   🔴 **要解决的问题**：⭐ 原来 `sample_bus_r` 是 **1024 个 FF**（⭐ 64 lane × 16 位），
    //      ⭐ 而 `tdm_render_mixer` 每拍要从这 1024 位里**用 `cnt_sel` 选 2 个 lane**
    //      ⇒ 🔴 两个 64:1 选路（⭐ ≈ 860 LUT）＋ 1024 个 FF **全都要布线**
    //      ⇒ ⭐ 这是本轮 **PnR 布线走不完**的头号负担 ✅
    //   ⭐ 本参数：⭐ `0`（**默认**）⇒ ⭐ 老路径**逐字、逐位、逐拍完全不变**（FF 数组 + 组合读）✅
    //               ⭐ `1` ⇒ ⭐ 换 **BSRAM + 2 个【寄存器】读口**：
    //                  ⭐ 写口：写地址 `cnt-1`、写数据 `rom_dout`（⭐ 每拍只写 1 个 lane ⇒ 天然适合 RAM）
    //                  ⭐ 读口：`osc_rd_addr0_i/1_i` → `osc_rd_data0_o/1_o`（⭐ 晚 1 拍）
    //
    //   🔴🔴 **⛔ 绝对不许掺"同址旁路"**（⭐ `rd_wr_same ? wr_data : mem[addr]`）：
    //      综合会推断 **write-through**（`WRITE_MODE=2'b10`），⭐ 而 Gowin 的 BSRAM
    //      只支持 `00`/`01` ⇒ 🔴 **PA2122 ⇒ 整个 PnR 失败**
    //      （⭐ 本项目已踩过一次，见 `evt_buf` 与 `AGENTS.md` 四之二·④）✅
    //   🔴 **一个 reg 只能在一个 always 块里赋值**（EX2000/EX1999）
    //      ⇒ ⭐ `osc_ram` 的所有**写入**只放在**一个** always 里 ✅
    //   📌 **拍数**：⭐ 读口是**寄存器输出** ⇒ 正好替代 `tdm_render_mixer` 里的 `vs_c_r` 那一级
    //      ⇒ ⭐ `dry_valid_o` 的**绝对拍数不变** ✅
    parameter integer OSC_RAM_EN        = 0,
    //  ⭐ 读口地址宽度（⭐ ⛔ 不要写死 6：⭐ 由 `POLY_TARGET*OSC_PER_VOICE` 推导）
    //     ⚠️ **必须与 `tdm_render_mixer.OSC_RD_AW` 同式**（⭐ 两侧端口位宽必须相等 ✅）
    parameter integer OSC_RD_AW         = ((POLY_TARGET * OSC_PER_VOICE) <= 1)
                                          ? 1 : $clog2(POLY_TARGET * OSC_PER_VOICE)
) (
    input  wire                                             clk_i,
    input  wire                                             rst_n_i,
    input  wire                                             sample_tick_i,
    input  wire [POLY_TARGET-1:0]                           voice_active_i,
    //  ⭐⭐⭐⭐ K-169（2026-09-30）新增：⭐ **每 voice 的"起音事件"相位复位** ✅
    //     ⭐ 源 = `note_manager.voice_retrig_reset_o`（⭐ 见 `top.v` 的例化 ✅）。
    //     ⭐ 语义 = **这个 voice 刚刚发生了一次 note_on**：
    //        · ⭐ `ST_COMMIT2`（⭐ 提交/抢占 ⇒ "新占 voice" ✅）置位
    //        · ⭐ `(f)` 段（⭐ 同轴重触发**复用**同一 voice ✅）置位
    //     ⚠️ **是"保持到 `sample_tick_i` 的电平"而⛔ 不是 1 拍脉冲** ——
    //        ⭐ 本模块相位只在 `sample_tick_i` 更新 ⇒ ⭐ 电平才能保证**必然被看见**
    //        （📌 与 `envelope_bank.retrig_reset_i` 是**同一个信号、同一条理由** ✅）
    //     🔴 **为什么必须新增它、而⛔ 不能用 `voice_active_i` 的上升沿**：
    //        ⭐ 详见下方 lane 生成块里的长注释（⭐ 一句话：⭐ `voice_active_i`
    //        是**电平派生**的，⭐ Release 尾巴里重按时**根本没有上升沿** ✅）
    //     ⚠️ **老例化不接本端口 ⇒ `z`** ⇒ ⭐ 由下方 `=== 1'b1` 解码为 **0**
    //        ⇒ ⭐ **行为与加本端口之前完全一致** ✅（⭐ 与 `note_manager` 的
    //        `vel_upd_src_i`"悬空 ⇒ 手弹(0)"是**同一套向后兼容口径** ✅）
    input  wire [POLY_TARGET-1:0]                           voice_phase_rst_i,
    input  wire [POLY_TARGET*PHASE_W-1:0]                   base_phase_inc_i,
    input  wire [POLY_TARGET*TIMBRE_W-1:0]                  voice_timbre_i,
    input  wire [POLY_TARGET*8-1:0]                         voice_velocity_i,
    //  ⭐⭐ 2026-09-29 新增（⭐ 鼓机噪声波表 · 阶段 2a）：⭐ **"本 voice 是鼓吗"**
    //     ⭐ 语义：⭐ `note_manager.voice_drum_o` —— ⭐ 判据 = `(src_r[i] == SRC_AUX)`，
    //        见 `note_manager.v` 的 `assign voice_drum_o[g]`；⛔ **不按轴号**（⭐ 旧文 `axis_r[i] >= RESERVED_AXIS` 已作废）
    //     ⭐ 用途：⭐ 这些 voice **改选第 10 张 pROM（宽带噪声表）**，⛔ 不用乐音表。
    //
    //   🔴 **为什么必须按 voice 送一个【独立标志】，而⛔ 不去加宽 `TIMBRE_W`（2→3）**：
    //      ⚠️ `TIMBRE_W` 是**冻结的 64 bit 事件格式**的一部分（⭐ `note_manager`
    //         / `evt_merge` / `looper` / 串口 `'I'` 全都在传它）⇒
    //         🔴 改它 = **整条事件通路返工** ＋ ⭐ 破坏所有已交付 tb 的位宽假设。
    //      ⭐ 而"是不是鼓"**本来就与音色无关**（⭐ 鼓靠**噪声**区分，⛔ 不靠音色号）
    //         ⇒ ⭐ 单开一根标志线是**最小且语义正确**的做法 ✅
    //   📌 位宽 = `POLY_TARGET`（⭐ 每 voice 1 位，⛔ 不是每 lane）——
    //      ⭐ 同一 voice 的两个失谐 lane **共用**这个标志（⭐ 两路都该是噪声 ✅）
    input  wire [POLY_TARGET-1:0]                           voice_drum_i,
    //  ⭐⭐ 2026-10-08（`A3` 正确修法）：⭐ **每 voice 的鼓分类**（⭐ 2 位：`[1]`=底鼓 · `[0]`=嗵鼓）
    //   ⭐ 由 `note_manager` 在**提交那一刻**算好（⭐ 见其 `ST_COMMIT2`）⇒ ⭐ **零窗口** ✅
    //   ⚠️ **只在 `DRUM_CLS_EXT != 0` 时被使用** ⇒ ⭐ 参数为 `0`（⭐ 所有 tb）时
    //      ⭐ 本端口**完全不参与综合**（⭐ 悬空 `Z` 也⛔ 不会传播 `x`）✅
    input  wire [POLY_TARGET*2-1:0]                         drum_cls_i,
    input  wire signed [15:0]                               vibrato_mod_i,
    input  wire                                             test_mode_i,
    input  wire [POLY_TARGET*OSC_PER_VOICE-1:0]             test_lane_active_i,
    input  wire [POLY_TARGET*OSC_PER_VOICE*PHASE_W-1:0]     test_phase_inc_i,
    input  wire                                             fm_cfg_valid_i,
    input  wire [15:0]                                      fm_ratio_i,
    input  wire [15:0]                                      fm_index_i,
    output wire [POLY_TARGET*OSC_PER_VOICE*OSC_SAMPLE_W-1:0] osc_sample_bus_o,
    output wire                                             osc_valid_o,
    output wire [PHASE_W-1:0]                               phase_acc_dbg_o,
    //  ⭐⭐ 2026-10-17：⭐ **osc 采样 BSRAM 的两个读口**（⭐ 只有 `OSC_RAM_EN != 0` 时有效）
    //     ⭐ 语义：⭐ `osc_rd_addr0_i/1_i` 是 **lane 号**（⛔ 不是 voice 号）
    //        ⭐ 地址**本拍**给出 ⇒ ⭐ 数据**下一拍**从 `osc_rd_data0_o/1_o` 出来 ✅
    //     ⚠️ `OSC_RAM_EN == 0` 时：⭐ 地址被忽略、⭐ 数据输出**恒 0**（⭐ 老路径不变 ✅）
    input  wire [OSC_RD_AW-1:0]                             osc_rd_addr0_i,
    input  wire [OSC_RD_AW-1:0]                             osc_rd_addr1_i,
    output wire [OSC_SAMPLE_W-1:0]                          osc_rd_data0_o,
    output wire [OSC_SAMPLE_W-1:0]                          osc_rd_data1_o
);

    localparam integer LANES = POLY_TARGET * OSC_PER_VOICE;
    localparam integer LW    = (LANES <= 1) ? 1 : $clog2(LANES);
    localparam integer AW    = (WT_DEPTH <= 1) ? 1 : $clog2(WT_DEPTH);   // 10

    // ⚠️ `AW` 必须与 `wavetable_bank` 的 `addr_i[9:0]` 一致（⭐ **1024 深** ——
    //    见 `wavetable_bank.v` 的 `parameter integer DEPTH = 1024` 与其 `initial` 契约自检）
    //    ⇒ 相位累加器取**高 AW 位**（MSB 对齐：DDS 的标准做法）
    localparam integer ADDR_MSB = PHASE_W - 1;
    localparam integer ADDR_LSB = PHASE_W - AW;

    // ⭐⭐ 2026-09-30 新增（阶段 2b）：⭐ **扫频计数器宽度 ＋ 分档门限的定宽常量** ✅
    //   ⭐ `16` 位 × ⭐ `<< 8` ⇒ ⭐ 偏移上限 = `65535 × 256 ≈ 16.7 M`
    //      ⇒ ⭐ 够表达"底鼓深度 = `INC_KICK`(6.44 M)"✅（⭐ 余量 2.6× ✅）
    //   ⚠️ `DRUM_KICK_MAX` / `DRUM_TOM_MAX` 是 `integer` 参数
    //      ⇒ 🔴 **必须先落定宽 `localparam` 再比较**（⭐ `K-91`：⛔ 不对 integer 做位选 ✅）
    localparam integer DRUM_SWEEP_W = 16;
    localparam [PHASE_W-1:0] DRUM_KICK_MAX_C = DRUM_KICK_MAX;
    localparam [PHASE_W-1:0] DRUM_TOM_MAX_C  = DRUM_TOM_MAX;
    //  ⭐⭐ 2026-10-04（P5-②）：⭐ **1/4 周期初相** —— ⭐ 原来写在 lane 里，
    //     ⭐ 现在提成**共享常量**（⭐ 只有 `OSC_IDX==1` 那个 lane 用它 ✅）
    //   📌 语义见下方 `phase_seed` 的长注释（⭐ "起音时一个是 sin、一个是 cos" ✅）
    localparam [PHASE_W-1:0] PHASE_QUARTER = {{(PHASE_W-2){1'b0}}, 2'b01} << (PHASE_W - 2);

    // ═══════════════════════════════════════════════════════════════════════
    // ① ⭐⭐ 64 个【独立】相位累加器 + 本帧地址锁存（generate 展开）
    //    ⭐ 用 `generate` 展开（⛔ 不是 `reg [31:0] phase [0:63]` 数组）——
    //       目的有两个：① 保证综合出 **64 份独立寄存器**（评委可数）；
    //       ② ⛔ 避免工具把数组推断成 BSRAM（那会**没法 64 路并行更新**）。
    // ═══════════════════════════════════════════════════════════════════════
    wire [LANES*AW-1:0]      lane_addr;      // 本帧各 lane 的查表地址
    wire [LANES*PHASE_W-1:0] lane_phase;     // 供调试观测
    wire [LANES*TIMBRE_W-1:0] lane_timbre;   // 起音锁存的每 voice 音色
    wire [LANES*8-1:0]       lane_velocity;  // 每 voice 力度（soft/hard 插值）
    //  ⭐⭐ 2026-09-29 新增：⭐ **每 lane 的"是鼓吗"**（⭐ 由每 voice 的标志展开到 lane）
    //   ⚠️ 为什么要**展开成 per-lane**（⭐ 而不是直接用 `voice_drum_i[req_idx/OSC_PER_VOICE]`）：
    //      ⭐ ① TDM 的 `req_idx` 是**运行期**索引，⭐ 用它去除法/乘法求 voice 号
    //            ⇒ ⚠️ 给 `oscillator_bank` 的关键路径**加一级除法器**（🔴 不可接受）；
    //      ⭐ ② 展平成 `LANES` 位后，⭐ 取值只是**一次线选**（⭐ 零逻辑）✅
    wire [LANES-1:0]         lane_drum;

    // ⭐ 颤音：**共享**一个乘法器算偏移（⛔ 不给每 lane 配乘法器 —— 那要 64 个 DSP）
    //    `vibrato_mod_i` 是 signed Q1.15 ∈ [-1, 1)
    //    `vib_off = VIB_REF_INC × vibrato_mod_i >> 15`
    //    ⚠️ 这是**共享的绝对偏移**（⛔ 不是每 lane 按各自基频比例）
    //       —— 理由：按比例需要每 lane 一个乘法器（64 DSP，占 60K 的 54%）。
    //       📌 已记 `K-95`；若将来要求"按比例颤音"，改成 TDM 复用同一个乘法器即可。
    //
    //  ⭐⭐ 2026-10-08（右手板时序修复）：⭐ **本条链加 2 级流水** ✅
    //   🔴 **为什么必须切**（⭐ 实测，`RIGHT_ADC_ENABLE=1` 档的 PnR 报告）：
    //      · 最差路径 **100% 是本条**：`u_vibrato_lfo/phase_q_17_s0/Q`
    //        → `u_oscillator_bank/gen_lane[*].phase_q_*_s0/D`
    //      · slack **−3.272 ns** · 数据延迟 **21.4 ns** vs 约束 **18.181 ns**
    //      · ⇒ ⭐ **1630 个端点同时违例** · TNS **−2718.329 ns**（⭐ 25 条最差路径全是它）
    //   ⭐ **病因**：⭐ 本条是**纯组合** —— `× VIB_REF_INC`（48 位常量乘法）+ 移位
    //      + 后面 32 位加法链 + ⭐ **扇出到 64 个 lane 的相位累加器** ✅
    //   ✅ **修法**：⭐ 切两刀（每刀一级寄存器）：
    //      ① `vibrato_mod_r` ← `vibrato_mod_i`（⭐ 把 LFO 的内部逻辑与乘法分开）
    //      ② `vib_mul_r`     ← `vibrato_mod_r × VIB_REF_INC`（⭐ 把乘法与后面的加法链分开）
    //   ⚠️ **代价**：⭐ 颤音延迟 **2 拍 = 40 ns** —— ⭐ 听感不可闻（颤音是 ~5 Hz 慢调制）✅
    //   📌 **代价极小**：⭐ 16 + 48 = **64 个 FF**，⛔ 几乎不加 LUT ✅
    //   ⚠️ **等价性**：⭐ 参考副本 `tb/models/oscillator_bank_ref.v` **同步加同一条流水**
    //      ⇒ ⭐ `tb_p5_osc_equiv` 的"逐位等价"判据**仍然成立**
    //      （⭐ 它验的是 **P5-② 上提的等价性**，⛔ 不是"与 2026-10-08 之前逐位相同"）✅
    reg  signed [15:0]  vibrato_mod_r;
    reg  signed [47:0]  vib_mul_r;
    always @(posedge clk_i) begin
        if (!rst_n_i) begin
            vibrato_mod_r <= 16'sd0;
            vib_mul_r     <= 48'sd0;
        end else begin
            vibrato_mod_r <= vibrato_mod_i;
            vib_mul_r     <= vibrato_mod_r * VIB_REF_INC;
        end
    end
    wire signed [PHASE_W-1:0] vib_off = vib_mul_r >>> 15;

    // ═══════════════════════════════════════════════════════════════════════
    //  ⭐⭐ 2026-10-04（P5-②）：⭐ **每 voice 一份的"增量 + 扫频"算术**
    //
    //  🔴 **为什么**：⭐ `OSC_PER_VOICE = 2` ⇒ 同一 voice 的两个 lane **共用同一个
    //     `base_phase_inc_i`** ⇒ ⚠️ 原来"每 lane 各算一遍"的这些东西**全是重复的**：
    //       ① 失谐偏移（纯移位）② 鼓判据（两级比较器）③ `sweep_load`（三目选择）
    //       ④ ⭐ **`sweep_q` 扫频计数器（16 位 × 64 lane ⇒ 现在只要 32 个）**
    //       ⑤ 相位增量的加法链
    //     ⇒ ⭐ 上提到 voice 级 ⇒ **这部分逻辑直接减半** ✅
    //
    //  ⭐ **为什么逐位等价**（⭐ ⛔ 不是"看起来一样"，⭐ 判据见 `tb/w3b/tb_p5_osc_equiv.sv`）：
    //     · ⭐ 加法在 **mod 2³²** 意义下**结合、交换** ⇒ ⭐ 原来
    //       `$signed(base)+$signed(detune)+$signed(vib)`（**33 位中间宽度**）
    //       与这里 `bv + vib_off[31:0] + so_v`（**32 位**）**截断后完全相同** ✅
    //     · ⭐ `sweep_q` 的**装载/衰减条件逐项照抄**（⭐ 含"test 档下仍然衰减"）✅
    //     · ⭐ `lane_active`（非 test 档）= `voice_active_i[VOICE_IDX]`
    //       ⇒ ⭐ **同一 voice 的两个 lane 恒等** ⇒ ⭐ 上升沿检测搬到 voice 级等价 ✅
    //     📌 实证：⭐ 参考副本 vs 本实现 **320 帧 0 mismatch**（⭐ 且比了**全部 64 个相位累加器**）
    //
    //  ⛔ **本块【不碰】相位累加器**：⭐ `phase_q`/`addr_q` 仍然**每 lane 一份**
    //     （⭐ 64 个相位累加器 = 评分主体，⭐ 一个都不能省 ✅）
    // ═══════════════════════════════════════════════════════════════════════
    //   ⭐ 每 voice 两份增量：⭐ 主 lane 用 `inc_main_w`、⭐ 失谐副本用 `inc_det_w`
    wire [POLY_TARGET*PHASE_W-1:0] inc_main_w;
    wire [POLY_TARGET*PHASE_W-1:0] inc_det_w;
    //   ⭐ 每 voice 上一拍"在响"（⭐ 用于取**起音上升沿** ✅）
    wire [POLY_TARGET-1:0]         act_d_bus;

    genvar vg;
    generate
        for (vg = 0; vg < POLY_TARGET; vg = vg + 1) begin : gen_voice
            //   ⭐ **本 voice 的基频增量**（⭐ 两个 lane 共用）
            wire [PHASE_W-1:0] bv = base_phase_inc_i[vg*PHASE_W +: PHASE_W];

            //   ⭐ 失谐偏移：⭐ `bv >> DETUNE_SH`（⭐ 纯移位，⛔ 无乘法器）
            //      ⚠️ `DETUNE_ON == 0` ⇒ ⭐ **偏移为 0** ⇒ ⭐ 两个 lane 同频（⛔ 无拍频）
            //      📌 **只有 `OSC_IDX == 1` 那个 lane 会加上它**（⭐ 见下方 `inc_det_w`）
            //         ⇒ ⭐ 两个 lane 频率【不同】⇒ ⭐ **拍频**
            //         ⇒ ⭐ 叠加从"严格 ×2"变成**自然的非相干叠加** ✅
            //   ⚠️ **`>>>` 还是 `>>`**：⭐ 此处 `bv` 是**无符号频率增量**
            //      （⭐ 相位增量恒正）⇒ ⭐ 两者等价 ⇒ ⭐ 用 `>>` 更直观
            wire [PHASE_W-1:0] dv = (DETUNE_ON != 0) ? (bv >> DETUNE_SH)
                                                     : {PHASE_W{1'b0}};

            //   ⭐ 鼓判据（⭐ 两级比较器，⭐ 纯组合、⭐ 无乘法 ✅）
            //     🔴 **必须与 `voice_drum_i` 相与** —— ⚠️ 否则一个"低音区"的**乐音** voice
            //        （⭐ 如 BASS 的低八度）也会被扫频 ⇒ 🔴 低音会"滑音" ✅
            //     ⚠️ 用 `bv`（⭐ 标称增量）而⛔ **不是**含失谐/颤音/本扫频的增量：
            //        ⭐ 后者会**自反馈**（⭐ 越扫越偏 ✅）
            //   ⭐⭐ 2026-10-08（`A3`）：⭐ **窗口问题与两版修法的完整记录**
            //     📌 `sim/evidence/a3-drum-raw-20261008/README.md` ✅
            //     🔴 **第一版**（⭐ 改读"未变调原始相位"＋ 阈值按八度缩放）：⭐ 窗口能清零，
            //        但 ⚠️ **阈值变成运行时值** ⇒ 2×32 个「常量比较器」变**全 32 位比较器**
            //        ⇒ 🔴 **实测 +2051 LUT（`CLS 78% → 82%`）** ⇒ ⭐ 回退 ✅
            //     ✅ **本版（正确修法）**：⭐ **把分类搬到提交路径**（⭐ `note_manager.ST_COMMIT2`）
            //        ＋ ⭐ **参数门控**（⭐ `DRUM_CLS_EXT`）⇒ ⭐ 生产档下那 64 个比较器
            //        **根本不参与综合** ⇒ ⭐ **净省 ~500 LUT** ✅
            //   ⭐⭐ 2026-10-08（`A3` 正确修法）：⭐ **分类来源由参数选** ✅
            //     · `DRUM_CLS_EXT = 0`（⭐ 默认）⇒ ⭐ 本模块自己比（⭐ 老行为；⭐ 所有 tb 走这条）✅
            //     · `DRUM_CLS_EXT = 1`（⭐ 生产）⇒ ⭐ 用 `note_manager` 提交时算好的分类 ✅
            //        ⇒ ⭐ **零窗口** ＋ ⭐ **那 64 个比较器不参与综合（净省 ~500 LUT）** ✅
            //   📌 参数是**编译期常量** ⇒ ⭐ 综合时直接折掉没选中的那支 ✅
            //   ⚠️ 注意：⭐ `DRUM_CLS_EXT=1` 时用 `drum_cls_i`（⭐ 2 位/voice）：
            //      `[vg*2+1]` = 底鼓 · `[vg*2+0]` = 嗵鼓 ✅
            wire drum_v  = (voice_drum_i[vg] === 1'b1);
            wire is_kick = drum_v && ((DRUM_CLS_EXT != 0)
                                      ? drum_cls_i[vg*2 + 1]
                                      : (bv <  DRUM_KICK_MAX_C));
            wire is_tom  = drum_v && ((DRUM_CLS_EXT != 0)
                                      ? drum_cls_i[vg*2 + 0]
                                      : ((bv >= DRUM_KICK_MAX_C) && (bv < DRUM_TOM_MAX_C)));

            //   ⭐ **本档的扫频深度**（⭐ `bv >> (LSB_SH + 本档 SH)` ⇒ ⭐ 纯连线 ✅）
            //     ⚠️ 赋给 16 位 ⇒ **高 16 位被截掉** ⇒ ⭐ 深度必须 < 65536
            //        （⭐ 底鼓 `5_368_709 >> 8  = 24466` ✅ · ⭐ 嗵鼓 `17_895_697 >> 10 = 13981` ✅）
            //        ⇒ ⭐ 模块末尾有**显式参数自检**（⭐ `K-106`：⛔ 不许静默截断 ✅）
            wire [DRUM_SWEEP_W-1:0] sweep_kick =
                bv >> (DRUM_SWEEP_LSB_SH + DRUM_KICK_SWEEP_SH);
            wire [DRUM_SWEEP_W-1:0] sweep_tom  =
                bv >> (DRUM_SWEEP_LSB_SH + DRUM_TOM_SWEEP_SH);
            //   ⭐ **装载值**：⭐ 非鼓 / 非底鼓嗵鼓 / 总开关关 ⇒ ⭐ **0（不扫）** ✅
            wire [DRUM_SWEEP_W-1:0] sweep_load =
                (DRUM_PITCH_ENV_EN == 0) ? {DRUM_SWEEP_W{1'b0}}
              : is_kick                  ? sweep_kick
              : is_tom                   ? sweep_tom
              :                            {DRUM_SWEEP_W{1'b0}};

            //   ⭐ **扫频计数器**（⭐ 阶段 2b 的寄存器 —— ⭐ 现在**每 voice 一个** ✅）
            reg  [DRUM_SWEEP_W-1:0] sweep_q;
            reg                     act_d;
            //  ⭐⭐ P0-31（2026-10-11）：⭐ **"上一拍采样看到起音"的标志** ✅
            //    ⭐ 语义：⭐ 把**装载**从"起音采样拍"推迟到"**下一个**采样拍" ✅
            //    🔴 **为什么必须推迟**（⭐ 审查 `[P0-31]`）：⭐ 装载值 `sweep_load` 乘的是 `bv`
            //       —— ⚠️ 而 `bv` = `base_phase_inc_i[vg]` = `note_manager.phase_tr[vg]`
            //    🔴 **`phase_tr[]` 是【轮转刷新】的**（`rot_cnt` 自由运行 ⇒ 每 **32 拍**
            //       才重写一条 lane，⭐ 写口还有 1 拍流水 ⇒ **≤33 拍** ✅）
            //       ⇒ ⭐ "提交"（改 `phase_r`）与"起音"（`voice_phase_rst_i`）**可能只差 1 拍**
            //       ⇒ 🔴 起音那一拍读到的 `bv` **还是【上一件鼓】的音高** ✅
            //       ⇒ 🔴 实测（`top.v` 生产参数）：⭐ 底鼓紧跟嗵鼓 ⇒ 深度 `2621`（应 `8738`，
            //          **浅 3.33×**）；⭐ 嗵鼓紧跟底鼓 ⇒ `69905` **超 16 位 ⇒ 截断成 `4369`**
            //          （应 `20971`，**深 4.8×**）⇒ ⭐ **"鼓不像鼓"** ✅
            //    ✅ **为什么"晚一拍"就【必然】够**（⭐ 不是经验值，⭐ 是推导）：
            //       · ⭐ `voice_phase_rst_i` 是**保持到 `sample_tick_i` 的电平**
            //          （⭐ `note_manager.v`：`retrig_reset_r` 在 `!sample_tick_i` 时置位、
            //            ⭐ 在 `sample_tick_i` 那拍清零 ⇒ ⭐ **恰好可见一个采样拍** ✅）
            //       · ⭐ 提交发生在**起音采样拍之前**（⭐ 电平被看见 ⇒ 提交必在它之前 ✅）
            //       · ⭐ 刷新 ≤ **33 拍** ≪ **一个采样拍 = 1024 拍** ✅
            //       ⇒ ⭐ **"下一个采样拍"时 `phase_tr[vg]` 必然已是提交后的值** ✅
            //    📌 **代价**：⭐ 每 voice **1 个 FF**（⭐ 32 个，⛔ 不是 224 个 ✅）
            //       ＋ ⭐ 起音**第一拍采样**不扫（⭐ 20.48 µs ÷ τ=21 ms = **0.1%** ⇒ 不可闻 ✅）
            //    📌 ⭐ 与"装载延后计数器（延后 40 拍）"那个方案的对比（⭐ 见审查 §八）：
            //       那个方案实测 **+352 LUT / +224 FF / +159 ALU**；⭐ 本方案 **+32 FF / ~30 LUT** ✅
            //       —— ⭐ 两者**都正确**（⭐ 40 拍 > 33 拍、⭐ 1 个采样拍也 > 33 拍），
            //          ⭐ 而本方案的"保证"**更强**（⭐ 1024 拍 ≫ 33 拍）且**更省** ✅
            //    ⚠️ **与老行为的唯一差别**：⭐ 起音后扫频**晚一拍生效**；
            //       ⭐ 若起音电平**持续多拍**（⭐ 非 `note_manager` 的用法），
            //       则 `onset_d` 保持 1 ⇒ ⭐ **每个采样拍都重装** ⇒ ⭐ 与老行为**逐拍相同** ✅
            reg                     onset_d;

            //   ⭐⭐ **衰减**：⭐ `sweep <= sweep - (sweep >> SH) - 1`（⭐ 每采样拍一次 ✅）
            //     · ⭐ `- (sweep>>SH)` ⇒ ⭐ **指数**衰减，⭐ 时间常数 ≈ `2^SH` 拍 ✅
            //        （⭐ 听感上"**先快后慢**"—— ⭐ 正是真实鼓的音高包络形状 ✅）
            //     · ⭐ `- 1`           ⇒ ⭐ **保证有限拍内精确到 0** ✅
            //        （⚠️ 只减 `sweep>>SH` 的话，`sweep < 2^SH` 之后**永远差一点**
            //         ⇒ 🔴 稳态频率被抬高 `sweep_q` 那一档 ⇒ 🔴 永远**settle 不到标称** ✅）
            //     📌 只有 `sweep_q != 0` 才衰减 —— ⚠️ 否则 `0 - 1` 会**回绕成全 1**
            //        ⇒ 🔴 稳态被加上一个**巨大**偏移 ✅
            wire [DRUM_SWEEP_W-1:0] sweep_dec =
                sweep_q - (sweep_q >> DRUM_SWEEP_SH) - 1'b1;

            //   ⭐ 本 voice 是否"在响"（⭐ 含 Release 尾巴 ✅）
            //     📌 **非 test 档下它就等于原来那个 per-lane 的 `lane_active`**
            //        （⭐ 因为 `lane_active = voice_active_i[VOICE_IDX]`，⭐ 同 voice 两 lane 恒等 ✅）
            wire act_v = test_mode_i ? test_lane_active_i[vg*OSC_PER_VOICE]
                                     : voice_active_i[vg];
            //   ⭐ 起音事件（⭐ 与 lane 级那条 `phase_rst_lane` **同源** ✅）
            wire rst_v = (voice_phase_rst_i[vg] === 1'b1);
            //   ⭐⭐ P0-31：⭐ **本采样拍的"起音条件"**（⭐ 逐项照抄原装载条件 ✅）
            //     📌 ⭐ 提成一根线只是为了让"判断"与"装载"分开写（⭐ 语义一字不变 ✅）
            wire onset_v = (!test_mode_i) && (rst_v || (act_v && !act_d));

            //   ⭐ **当前额外增量**（⭐ 左移定标 ⇒ ⭐ 纯连线、⛔ 无乘法器 ✅）
            wire [PHASE_W-1:0] so_v =
                {{(PHASE_W-DRUM_SWEEP_W){1'b0}}, sweep_q} << DRUM_SWEEP_LSB_SH;

            always @(posedge clk_i) begin
                if (!rst_n_i) begin
                    sweep_q <= {DRUM_SWEEP_W{1'b0}};   // ⭐ 复位 ⇒ 无扫频
                    act_d   <= 1'b0;
                    onset_d <= 1'b0;
                end else if (sample_tick_i) begin
                    act_d   <= act_v;
                    //  ⭐⭐ P0-31：⭐ **记住"本拍看到了起音"** ⇒ ⭐ 下一拍才装载 ✅
                    onset_d <= onset_v;
                    //  ⭐⭐ 装载条件**逐项照抄**原来的 lane 级写法：
                    //     `!test_mode_i && (phase_rst_lane || (lane_active && !lane_active_d))`
                    //     ⚠️ 注意：⭐ **test 档下不装载、但仍然衰减**（⭐ 与原来逐项一致 ✅）
                    //  ⭐⭐ P0-31（2026-10-11）：⭐ **装载推迟到"下一个采样拍"** ✅
                    //     · ⭐ `onset_d`（⭐ = 上一拍采样的 `onset_v`）⇒ ⭐ **现在**装载
                    //        —— ⭐ 此刻 `phase_tr[vg]` 必然已刷过（⭐ 见上方长注释的推导 ✅）
                    //     · ⭐ `onset_v`（⭐ 起音当拍）⇒ ⭐ **只清 0、先不扫** ✅
                    //     📌 ⭐ **优先级**：⭐ `onset_d` 在前 ⇒ ⭐ 起音电平**持续多拍**时
                    //        `onset_d` 也持续为 1 ⇒ ⭐ **每拍重装** ⇒ ⭐ 与老行为逐拍相同 ✅
                    if (onset_d)
                        sweep_q <= sweep_load;
                    else if (onset_v)
                        sweep_q <= {DRUM_SWEEP_W{1'b0}};
                    else if (sweep_q != {DRUM_SWEEP_W{1'b0}})
                        sweep_q <= sweep_dec;
                end
            end

            assign act_d_bus[vg] = act_d;
            //   ⭐⭐ **相位增量**：⭐ 主 lane = 基频 + 颤音 + 本 voice 的扫频偏移
            //      ⭐ 失谐副本 = 主 lane 的增量 **＋ 失谐偏移**
            //     📌 32 位无符号加法（⭐ mod 2³²）与原来 33 位有符号加法**截断后等价** ✅
            assign inc_main_w[vg*PHASE_W +: PHASE_W] = bv + vib_off[PHASE_W-1:0] + so_v;
            assign inc_det_w [vg*PHASE_W +: PHASE_W] =
                inc_main_w[vg*PHASE_W +: PHASE_W] + dv;
        end
    endgenerate

    genvar g;
    generate
        for (g = 0; g < LANES; g = g + 1) begin : gen_lane
            // 该 lane 属于哪个 voice（lane = voice*OSC_PER_VOICE + osc）
            localparam integer VOICE_IDX = g / OSC_PER_VOICE;
            //   ⭐ 本 lane 是 voice 内第几个 osc（⭐ 0 = 主、1 = 失谐副本）
            //   📌 **为什么用 `localparam` 而⛔ 不直接写 `g % OSC_PER_VOICE`**：
            //      ⭐ `g` 是 `genvar` ⇒ ⭐ 取模必须落在**编译期常量**里
            //      （⭐ `K-91` 同族：⛔ 不对 `integer` 参数做运行期运算）
            localparam integer OSC_IDX  = g % OSC_PER_VOICE;

            reg [PHASE_W-1:0] phase_q;
            reg [AW-1:0]      addr_q;

            //   ⭐ 本 lane 是否"在响"（⭐ 含 Release 尾巴 ✅）
            wire lane_active = test_mode_i
                             ? test_lane_active_i[g]
                             : voice_active_i[VOICE_IDX];

            //  ⭐⭐ K-169（2026-09-30）：⭐ **本 lane 的"起音事件"相位复位** ✅
            //     ⭐ 直接来自 `voice_phase_rst_i`（⭐ = `note_manager` 的每 voice
            //        note_on 事件 ✅），⛔ **不再从 `lane_active` 的电平边沿反推** ✅
            //     ⚠️ `=== 1'b1`（⛔ 不是 `if (voice_phase_rst_i[...])`）是**必需的**：
            //        ⭐ 老例化**不接**本端口 ⇒ 该位是 `z` ⇒ ⚠️ 用普通 `if` 会得到 `x`
            //        ⇒ 🔴 判据真假不定（⭐ 这正是 `note_manager.v` 里
            //        `vu_src_w`/`pu_src_w` 当初必须显式解码的**同一个坑** ✅）
            wire phase_rst_lane = (voice_phase_rst_i[VOICE_IDX] === 1'b1);

            //  ⭐⭐⭐⭐ 2026-09-29 **治本**：⭐ **起音时把相位复位到设计初相** ✅
            //   🔴 **上板症状（⭐ 用户原话）**：*"无论按下的行程多少，都是原始音量"* ✅
            //      ⭐ 且用户给出决定性观察：*"我快速地每次都按到底，用微分积分的思想来看，
            //      就和长按的音量变化是一样的，还是失谐的正弦波的音量起伏"* ✅
            //      ⇒ ⭐ **快速连按 = 对拍频包络做【采样】** ⇒ ⭐ **每次起音的音量 =
            //        失谐两 lane 当时的相位关系**（⭐ 0.25× ~ 2.0× ✅）✅
            //   🔴 **根因**：⭐ `phase_q` 只在 `rst_n_i` 时取 `phase_seed` ✅，
            //      ⭐ 之后**永远累加** ⇒ ⚠️ 未激活时**保持上次的值**（⭐ 无 `else` ✅）
            //      ⇒ 🔴 **第一个音之后，0°/90° 这个设计初相关系就【丢失】了** ✅
            //      ⇒ 🔴 **每次起音的叠加幅度随机** ✅
            //   ✅ **修法**：⭐ 取 `lane_active` 的**上升沿**（⭐ = `note_on` ✅）
            //      ⇒ ⭐ `phase_q <= phase_seed`（⭐ 回到设计初相 ✅）
            //   📌 **为什么这正是【设计者本来的意图】**：⭐ `phase_seed` 的注释原文 ——
            //      *"给它一个 1/4 周期初相 ⇒ 起音时一个是 `sin`、一个是 `cos`
            //      ⇒ ✅ 既不抵消、也不叠加（⭐ 幅度平稳）"* ✅
            //      ⇒ ⭐ **它就是为"起音"设计的** ✅ ⛔ **却只接到了复位** ✅
            //   ⚠️ **"清零会产生咔声"这条顾虑对 `note_on` 【不成立】**：
            //      ⭐ 起音时包络从 **0** 起 ⇒ ⭐ **没有可听的不连续** ✅
            //      （⭐ 该顾虑对"**在响时**改相位"成立 —— ⭐ 例如滑音 ✅ 见 `pitch_upd` ✅）
            //   📌 **成本**：⭐ 每 lane 1 个 FF（⭐ 64 个 ✅）＋ ⭐ 一个 `phase_seed` 载入 ✅
            //   ⭐⭐ 2026-10-04（P5-②）：⭐ **"上一拍是否在响"已经上提到 `gen_voice`**
            //      （⭐ 非 test 档下同 voice 的两个 lane 恒等 ⇒ ⭐ 搬到 voice 级等价 ✅）
            //      ⇒ ⭐ 本 lane 用 `act_d_bus[VOICE_IDX]` 取**起音上升沿** ✅

            //   ⭐⭐ 2026-10-04（P5-②）：⭐ **基频增量 / 失谐偏移已上提到 `gen_voice`**
            //      ⇒ ⭐ 本 lane 只剩"**选哪一份**"：⭐ 主 lane 用 `inc_main_w`、
            //         ⭐ 失谐副本（`OSC_IDX != 0`）用 `inc_det_w` ✅
            //      📌 "只有失谐副本才加偏移"这条语义 ⇒ ⭐ 见 `gen_voice` 的 `dv`/`inc_det_w` ✅
            wire [PHASE_W-1:0] lane_inc_base =
                (OSC_IDX != 0) ? inc_det_w[VOICE_IDX*PHASE_W +: PHASE_W]
                               : inc_main_w[VOICE_IDX*PHASE_W +: PHASE_W];

            //  ⭐⭐ **2026-09-28 的历史修复（⭐ 结论保留；写法已随 P5-② 上提到 `gen_voice`）**
            //
            //  🔴 **当年的症状**：⭐ 颤音**负半周**出现宽带噪声 / 孤立尖峰
            //     （⭐ 与用户 DS0004 实测吻合）。
            //     ⚠️ 当时的写法把三个量**按无符号**求值（⭐ Verilog 规则：表达式中只要有**一个**
            //        操作数无符号，整个表达式就按无符号求值）⇒ 怀疑 `vib_off` 的符号被丢。
            //  ✅ **当年的修法**：把两个无符号量**零扩展后转有符号**，让加法链**全程按有符号**
            //     求值，最后截到 `PHASE_W` 位 ⇒ ⭐ 相位累加器（无符号、故意回绕）拿到的
            //     仍是**正确增量** ✅
            //
            //  ⭐⭐ **2026-10-04（P5-②）的等价性论证**（⭐ 这就是"上提"合法的依据）：
            //     ⭐ 加法在 **mod 2³²** 下**结合、交换** ⇒ ⭐ "33 位有符号和**截断到 32 位**"
            //        与 "32 位无符号和" **逐位相同** ✅
            //     ⇒ ⭐ 现在写成 `inc_main_w = bv + vib_off[31:0] + so_v`（⭐ 见 `gen_voice`）
            //        —— ⭐ **既保住当年修法的效果，又省掉一级 33 位加法器** ✅
            //     📌 判据：⭐ `tb/w3b/tb_p5_osc_equiv.sv` 比**全部 64 个相位累加器**，
            //        320 帧 **0 mismatch**（⭐ 且 `vibrato` 扫过 −15000…+15000 全量程 ✅）

            //  ═══════════════════════════════════════════════════════════
            //  ⭐⭐⭐⭐ 2026-09-30 新增（阶段 2b）：⭐ **鼓 lane 的向下扫频** ✅
            //    ⭐ 目的：⭐ 让底鼓/嗵鼓起音时**瞬时频率高于标称**、⭐ 然后**指数回落**
            //       ⇒ ⭐ 稳态**精确**回到 `PHASE_INC`（⭐ 偏移衰减到 0 ✅）
            //    📌 参数语义与"为什么用音高分档"见模块头的长注释（⛔ 此处不重复 ✅）
            //  🔴🔴 **2026-10-04（P5-②）：⭐ 整块（鼓判据 / `sweep_load` / `sweep_q` /
            //      `sweep_dec` / 增量加法）已经【整体上提到 `gen_voice`】** ——
            //     ⭐ 因为 `OSC_PER_VOICE = 2` ⇒ 同一 voice 的两个 lane 本来就得到
            //        **完全相同**的 `is_kick`/`is_tom`/`sweep_load`/`sweep_q` ✅
            //     ⇒ ⭐ 语义、条件、衰减算法**逐项照抄**（⭐ 见 `gen_voice` 里那段注释）
            //     ⚠️ 唯一变化：⭐ `sweep_q` 从 **64 个（每 lane）** 变成 **32 个（每 voice）**
            //  ═══════════════════════════════════════════════════════════

            //   ⭐⭐ 把"本 lane 的相位增量"接上（⭐ 算术已在 `gen_voice` 算好 ✅）
            //
            //  ⭐⭐⭐⭐ 2026-10-11（⭐ **P2-37 实验：结论 = 不成立，已回退**）✅
            //
            //  ⭐ **审查的假设**（⭐ `[P2-37]`）：⭐ 奇数 lane（`OSC_IDX == 1`）的 test 覆盖
            //     mux 是**白付的** ⇒ ⭐ 预期省 **500~1000 LUT4** ✅
            //  ⭐ **实测（⭐ 判据是审查自己定的"LUT 降 ≥ 500"）**：
            //     🔴 **资源一个字节都没变** —— `T_Lut 28045` · `LUT 28039` · `CLS 24359`
            //        ⭐ 与改前**完全相同** ✅
            //     ＋ ⚠️ 而 `tb/w3b/tb_oscillator_bank.sv` **红了**（⭐ 行为**确实**变了 ✅）
            //  ✅ **结论**：⭐ **综合器早就把它折掉了** ——
            //     ⭐ 因为 `lane_active = 0` 时 `phase_q <= phase_q + lane_inc` **整条不执行**
            //        ⇒ ⭐ 综合器能看出"**test 档下奇数 lane 的 `lane_inc` 是死逻辑**" ✅
            //     ⇒ ⭐ **审查的估算（≈1000 LUT4）是错的** ✅（⭐ 所以它自己写着"**先做实验判定**" ✅）
            //  ✅ **处置：按判据回退** —— ⭐ 审查原文：*"判据：综合报告 LUT 下降 ≥ 500 …
            //     ⇒ 白付确认，落地"* ⇒ ⭐ **未达判据 ⇒ 不落地** ✅
            //  📌 ⭐ **顺带得到一条更有用的信息**：⭐ 本改动**会改变模块级契约**
            //     （⭐ `tb_oscillator_bank` 直接驱动奇数 lane 的 `test_phase_inc_i` 非 0 ✅）
            //     ⇒ ⭐ 审查那句"在生产接线下是编译期常量 0"**只对顶层接线成立**，
            //        ⚠️ **对模块级不成立** ✅ ⇒ ⭐ **又一条"不落地"的理由** ✅
            //  ⭐⭐⭐⭐ 2026-10-17（🔴 **T1 实验 · 只跑综合定案**）：
            //     ⭐ 把 test 覆盖**由 `test_lane_active_i[g]` 门控** ✅
            //     📌 **与上面 P2-37 的改法【不同】**（⭐ 那个用 `(test_mode_i && (OSC_IDX==0))`）：
            //        · P2-37：⭐ 只让 `OSC_IDX==0` 的 lane 拿 test 值 ⇒ ⚠️ **改了模块级契约**
            //        · T1：⭐ 用 `test_lane_active_i[g]` ⇒ ⭐ **与 `lane_active` 同源**
            //          （⭐ `:532-534` `lane_active ≡ test_mode_i ? test_lane_active_i[g] : ...`）
            //          ⇒ ⭐ `test_mode_i=1` 时新条件**恒等于 `lane_active`**
            //          ⇒ ⭐ 两者只在 `lane_active=0`（⭐ 寄存器不更新）时不同
            //          ⇒ ⭐ **对任意输入组合输出逐位相同** ⇒ ⛔ **不改模块级契约** ✅
            //     🔴 **为什么值得再试一次**（⭐ 只读审计 P 的网表实测，⭐ 03:32 那版）：
            //        ⭐ `\gen_lane[odd].lane_inc_*_s2` 有 **992 个 `LUT2`（`INIT=4'h4`，
            //        输入 `{tm_enable_q_16, inc_det_w[i]}`）** 确实在**顶层网表**里 ✅
            //        ⇒ ⭐ **与 P2-37 的"逐字节不变"矛盾** ⇒ 只能实测定案 ✅
            //     📌 **判据（⭐ P 给的，⭐ 只跑综合、⛔ 不跑 PnR）**：
            //        ⭐ ① `Gowin2026.vg` 里 `\gen_lane[\d*[13579]]\.lane_inc_\d+_s2` 的
            //             实例数 **992 → 0**；
            //        ⭐ ② `_syn_rsc.xml` 里 `u_oscillator_bank` 的 `Lut` **6279 → ≈5287**；
            //        ⭐ ③ 顶层 `T_Lut` 降幅 **≥500 ⇒ 落地；否则【回退】** ✅
            //     ⚠️ **回退**：把条件改回 `test_mode_i`（⭐ 一行 ✓）
            //     ⚠️ **若落地**：⭐ 必须同步 `tb/models/oscillator_bank_ref.v` ✅
            wire [PHASE_W-1:0] lane_inc = (test_mode_i && test_lane_active_i[g])
                             ? test_phase_inc_i[g*PHASE_W +: PHASE_W]
                             : lane_inc_base;

            //   ⭐⭐ **去相关初相**（⭐ 2026-09-26 新增，⭐ 学自 `xls32` 源码）
            //
            //   ⭐ **`xls32` 的原话**（⭐ `core/synth.x` 的 `apply_on`）：
            //      > *"a **DECORRELATED** start phase seeded from the LFSR (distinct per
            //      >  stack index) so the copies **don't sum coherently at the attack**
            //      > (**no N* spike -> headroom**) and thicken immediately."*
            //   📌 它给每个 unison 副本一个 **LFSR 随机初相**：⭐ `phase: seed`
            //
            //   🔴 **为什么我们也需要**（⭐ 即使已经失谐）：
            //      ⚠️ 失谐解决的是【稳态】（⭐ 拍频让两路慢慢错开）
            //      🔴 但**起音那一瞬间**，两个 lane 的 `phase_q` **都从 0 开始**
            //         ⇒ ⭐ **头几个周期仍严格同相** ⇒ 🔴 **起音有幅度尖峰**
            //      ⭐ 给它一个 **1/4 周期初相** ⇒ ⭐ 起音时一个是 `sin`、一个是 `cos`
            //         ⇒ ✅ **既不抵消、也不叠加**（⭐ 幅度平稳）
            //
            //   ⭐ **为什么用 1/4 周期而⛔ 不用 `xls32` 的 LFSR**：
            //      · ⭐ `xls32` 有 **4 个 unison 副本** ⇒ ⚠️ 需要"各不相同"的随机相位
            //      · ⭐ 我们**只有 1 个失谐副本**（⭐ `OSC_PER_VOICE=2`）
            //        ⇒ ⭐ **两个固定位置（0 与 1/4 周期）就够** ⇒ ⛔ **不必加 LFSR**
            //      📌 零额外逻辑（⭐ 只是一个常量），⛔ 不引新寄存器。
            //   ⚠️ **为什么⛔ 不是 1/2 周期（180°）**：⭐ 那会让两路**反相**
            //      ⇒ 🔴 **起音瞬间完全抵消**（⭐ 声音"先弱后强"，⭐ 更糟）。
            //   📌 `PHASE_W=32` ⇒ 1/4 周期 = `32'h4000_0000`
            //   ⭐ 2026-10-04（P5-②）：⭐ 常量提成模块级 `PHASE_QUARTER`（⭐ 只此一处定义 ✅）
            wire [PHASE_W-1:0] phase_seed =
                ((DETUNE_ON != 0) && (OSC_IDX != 0))
                ? PHASE_QUARTER
                : {PHASE_W{1'b0}};

            always @(posedge clk_i) begin
                if (!rst_n_i) begin
                    //   ⭐ 复位时**直接给去相关初相**（⭐ 不是全 0）
                    //   ⭐ 2026-10-04（P5-②）：⭐ `sweep_q`/`act_d` 已搬到 `gen_voice` ✅
                    phase_q <= phase_seed;
                    addr_q  <= {AW{1'b0}};
                end else if (sample_tick_i) begin
                    // ⭐ 地址锁存用**本帧起始**的相位（DDS 标准做法），
                    //   然后相位再前进 ⇒ ⭐ 保证整帧 64 个样本来自**同一时刻**的相位
                    //   （对应接口表 "osc_sample_bus_i 稳定至本帧结束"）
                    addr_q <= phase_q[ADDR_MSB:ADDR_LSB];
                    // ⭐⭐⭐⭐ 2026-09-29 **治本**：⭐ 起音（上升沿）⇒ 复位到设计初相 ✅
                    //   🔴 **原行为**：⭐ `if (lane_active) phase_q <= phase_q + inc;`
                    //      —— ⭐ **无 `else`** ⇒ ⭐ 未激活时**保持相位** ✅
                    //      ⇒ 🔴 起音相位 = **上次遗留的任意值** ⇒ ⭐ 叠加幅度随机 ✅
                    //   ✅ **新行为**：⭐ 上升沿载入 `phase_seed`（⭐ lane0 = 0°、
                    //      lane1 = 90° ✅）⇒ ⭐ **每个音都从同一个初相开始** ✅
                    //      ⇒ ⭐ **同深度 ⇒ 同音量** ✅
                    //   📌 载入那一拍**不累加**（⭐ 相位从种子起步 ✅）
                    //   ⚠️ **只在【正式通路】做**（⭐ `!test_mode_i` ✅）——
                    //      ⭐ `T43`/`T55` 的 test-mode 判据建立在"**test 覆盖下相位照常前进**"
                    //      ⭐ 之上（⭐ 如 `test_mode=1 overrides voice_active=0` ✅）
                    //      ⇒ ⭐ 若在那里也复位种子，⭐ 会打破它们 ✅（⭐ 实测 5 条红 ✅）
                    //  ═══════════════════════════════════════════════════════
                    //  ⭐⭐⭐⭐ K-169（2026-09-30）：⭐ **相位复位改挂 note_on 事件边沿** ✅
                    //
                    //  🔴 **上板症状**（⭐ 用户原话）：*"按下满行程的键，**不同时间按下**，
                    //     音量不同"* ⇒ ⭐ 快速连按时**起音幅度忽大忽小** ✅
                    //
                    //  🔴 **根因 = 挂错了边沿**：⭐ 上一版把"起音复位"挂在 `lane_active`
                    //     （⭐ = `voice_active_i` = `note_manager.live_mask` ✅）的
                    //     **上升沿** 上，⚠️ 而 `lane_active` 是**电平派生**的：
                    //        ⭐ `live_mask = gate_r | retrig_low | env_active_i`
                    //        ⇒ ⭐ 上一个音**还在 Release 尾巴里**（`env_active_i=1` ✅）
                    //          时再按**同一个轴** ⇒ ⭐ `live_mask` **恒为 1**
                    //        ⇒ 🔴 **上升沿【根本不存在】** ⇒ ⭐ 复位被跳过 ✅
                    //     ⇒ 🔴 新音从上一次的**残留相位**起振 ⇒ ⭐ 两个失谐 lane 的
                    //        设计初相关系（0° / 90°）丢失 ⇒ ⭐ **叠加幅度随机**
                    //        （⭐ 0.25× ~ 2.0×）⇒ ⭐ 与"同深度不同时间音量不同"**完全吻合** ✅
                    //
                    //  📌 **这是"偶发尖音"家族的另一个缺口**（⭐ 不是同一个 bug）：
                    //     ⭐ `tb/w3b/tb_retrig_reset_span.sv:303-317` 已经证明
                    //     "**松手后仍在 Release 里再按**"这条路**确实发出了**清零脉冲
                    //     （⭐ `retrig_reset_r` ⇒ ⭐ 包络那一路拿到了 ✅）
                    //     —— ⚠️ **只有振荡器这一路没拿到**，⭐ 因为它盯的是**电平边沿** ✅
                    //
                    //  ✅ **修法**：⭐ 复位改挂 `phase_rst_lane`
                    //     （⭐ = `voice_phase_rst_i` = `note_manager.voice_retrig_reset_o`）
                    //     —— ⭐ 它**就是**每 voice 的 `note_on` **事件**：
                    //        · ⭐ `ST_COMMIT2`（⭐ 提交/抢占 ⇒ 新占 voice ✅）置位
                    //        · ⭐ `(f)` 段（⭐ 同轴重触发复用 ✅）置位
                    //     ⇒ ⭐ **两条起音路径都覆盖**，⭐ 与"包络清零"**同源同拍** ✅
                    //     ⇒ ⛔ 不再依赖任何**电平**的边沿 ✅
                    //
                    //  ⭐ **为什么保留旧的上升沿判据（`||` 而不是替换）**：
                    //     ⚠️ 老例化（`tb_oscillator_bank` / `tb_top_*` / `bringup/*`）
                    //     **不接** `voice_phase_rst_i` ⇒ `z` ⇒ ⭐ 解码为 0
                    //     ⇒ ⭐ **只有旧判据生效** ⇒ ⭐ **那些验收判据一条都不动** ✅
                    //     （📌 实证：`tb_oscillator_bank` 的"两次起音逐位相同"正是
                    //      靠这条电平判据 —— ⛔ 直接删掉它会踩验收契约 ✅）
                    //     ⭐ 且新判据在"新占 voice"时与旧判据**同拍**（都是
                    //     `sample_tick_i` 那一拍）⇒ ⭐ 不会重复载入 ✅
                    //     📌 语义上：⭐ **事件边沿是权威触发**，⭐ 电平边沿是**向后兼容兜底** ✅
                    //
                    //  📌 **代价**：⭐ 每 lane 1 个 2 输入 OR ＋ 1 个 1 位比较 ⇒ 可忽略 ✅
                    //  ═══════════════════════════════════════════════════════
                    if (!test_mode_i && (phase_rst_lane
                                         || (lane_active && !act_d_bus[VOICE_IDX]))) begin
                        phase_q <= phase_seed;         // ⭐ 起音：回到设计初相
                        //  ⭐⭐ 阶段 2b：⭐ **起音 ⇒ 装载本档的扫频深度** ✅
                        //     🔴 **为什么必须挂在【同一个条件】上**：⭐ 扫频是"**起音事件**"
                        //        的包络 ⇒ ⭐ 与相位复位**同源同拍**才不会错位 ✅
                        //        （⭐ `voice_phase_rst_i` 那条新路径 / ⭐ `lane_active`
                        //         上升沿那条兼容路径 **两条都覆盖** ✅）
                        //     ⭐ 非鼓 / ⭐ 军鼓踩镲 / ⭐ 总开关关 ⇒ ⭐ `sweep_load = 0`
                        //        ⇒ ⭐ **行为与加本功能之前完全一致** ✅
                        //     🔴 2026-10-04（P5-②）：⭐ **"装载"本身已搬到 `gen_voice`**
                        //        （⭐ 条件**逐项照抄**：`!test_mode_i && (rst_v || (act_v && !act_d))`）
                        //        ⇒ ⭐ 本块**只管相位**；⭐ 两件事仍然**同源同拍** ✅
                    end else begin
                        if (lane_active)
                            phase_q <= phase_q + lane_inc;
                        //  ⭐⭐ 阶段 2b：⭐ **扫频衰减**（⭐ 每采样拍一次 ✅）
                        //     📌 **与 `lane_active` 无关** —— ⭐ 扫频是"**时间**包络"，
                        //        ⛔ 不是"相位"包络；⭐ 且非鼓 lane 的 `sweep_q` 恒为 0 ✅
                        //        ⇒ ⭐ 少一级门控（⭐ 省逻辑、⭐ 且语义更直白 ✅）
                        //     🔴 2026-10-04（P5-②）：⭐ **衰减也已搬到 `gen_voice`** ✅
                    end
                end
            end

            assign lane_addr[g*AW +: AW]       = addr_q;
            assign lane_phase[g*PHASE_W +: PHASE_W] = phase_q;
            assign lane_timbre[g*TIMBRE_W +: TIMBRE_W] =
                voice_timbre_i[VOICE_IDX*TIMBRE_W +: TIMBRE_W];
            assign lane_velocity[g*8 +: 8] = voice_velocity_i[VOICE_IDX*8 +: 8];
            //  ⭐⭐ 2026-09-29 新增：⭐ **本 lane 是否走噪声表**（⭐ 鼓机专用 ✅）
            //   🔴🔴 **为什么必须用 `=== 1'b1` 而⛔ 不能直接引用 `voice_drum_i[VOICE_IDX]`**：
            //      ⭐ 本端口是**后加的** ⇒ ⚠️ 老 tb（`tb_oscillator_bank` /
            //         `tb_soft_hard_blend` / `tb_velocity_*` …）**不接它** ⇒ 悬空 = `z`
            //      ⇒ 🔴 若直接拿 `z` 当三目选择端 ⇒ `rom_dout` 变成 `x`
            //         ⇒ 🔴 **所有老用例集体假红**（⭐ 与 `note_manager` 的
            //         `vel_upd_src_i` 悬空问题是**同一类**，⭐ 见那里的"悬空 = 手弹"口径 ✅）。
            //   ⭐ 口径：⭐ **只有明确的 1 才当"鼓"**，⭐ 其余（含 `x`/`z`）一律当**非鼓**
            //      ⇒ ⭐ **行为与加此端口前完全一致**（⭐ 全部走乐音表 ✅）
            assign lane_drum[g] = (voice_drum_i[VOICE_IDX] === 1'b1);
        end
    endgenerate

    // ═══════════════════════════════════════════════════════════════════════
    // ② TDM 时序：固定 LANES+2 拍（⛔ 无变长搜索）
    // ═══════════════════════════════════════════════════════════════════════
    reg [LW:0]  cnt;          // 0 .. LANES（需要 LW+1 位才装得下 LANES）
    reg         rendering;
    reg         valid_r;

    always @(posedge clk_i) begin
        if (!rst_n_i) begin
            cnt       <= {(LW+1){1'b0}};
            rendering <= 1'b0;
            valid_r   <= 1'b0;
        end else if (sample_tick_i) begin
            // 新一帧：从 lane 0 开始重新取
            cnt       <= {(LW+1){1'b0}};
            rendering <= 1'b1;
            valid_r   <= 1'b0;
        end else if (rendering) begin
            if (cnt == LANES[LW:0])
                rendering <= 1'b0;          // 全部取完
            else
                cnt <= cnt + 1'b1;
            // ⭐ 最后一拍：此刻 `rom_dout` 是 lane LANES-1 的数据 ⇒ 下一拍报 valid
            valid_r <= (cnt == LANES[LW:0]);
        end else begin
            valid_r <= 1'b0;
        end
    end

    wire [LW-1:0] req_idx = cnt[LW-1:0];
    // 只在 0..LANES-1 期间送地址（⛔ 避免越界读）
    wire          req_active = rendering && (cnt < LANES[LW:0]);
    wire [AW-1:0] rom_ad     = lane_addr[req_idx*AW +: AW];
    wire [TIMBRE_W-1:0] rom_timbre = lane_timbre[req_idx*TIMBRE_W +: TIMBRE_W];
    wire [7:0] req_velocity = lane_velocity[req_idx*8 +: 8];
    //  ⭐⭐ 2026-09-29 新增：⭐ **本次 TDM 请求落在的 lane 是不是鼓**（⭐ 与地址同拍送 ✅）
    wire       req_drum     = lane_drum[req_idx];

    // ═══════════════════════════════════════════════════════════════════════
    // ③ 1 个【共享】四音色波表（4 × soft/hard × 1024，1 级同步读）
    //    表常量由 `tools/gen_t31b_wavetable.py` 生成并嵌入 RTL；
    //    仿真和 Gowin 综合使用同一组样本，避免双实现漂移。
    // ═══════════════════════════════════════════════════════════════════════
    wire signed [WT_W-1:0] rom_soft;
    wire signed [WT_W-1:0] rom_hard;
    //  ⭐⭐ 2026-09-29 追加：⭐ **Test Mode 专用的【纯正弦】表**（⭐ 与音色解耦 ✅）
    //   ⭐ 由 `wavetable_bank` 的第 9 个 pROM `rom_test_sine_inst` 提供 ✅
    //   📌 为什么要单独一张：⭐ 四音色（AKWF）**谐波丰富** ⇒ ⭐ 借它们做 Test Mode
    //      ⇒ 🔴 谐波被 `peak_count` 数成谱峰 ⇒ 🔴 M4 判据（4/8/16/32）变红 ✅
    wire signed [WT_W-1:0] rom_test;
    //  ⭐⭐ 2026-09-29 新增：⭐ **鼓机专用的【宽带噪声表】**（⭐ 第 10 个 pROM ✅）
    //   ⭐ 由 `wavetable_bank` 的 `rom_noise_inst` 提供（⭐ 与其余 9 张表**同源同拍**）✅
    //   📌 为什么鼓要噪声：⭐ `drum_gen` 的 4 件乐器**共用同一个 `AXIS_ID`**，
    //      ⭐ 原来只靠 `PHASE_INC`（音高）区分 ⇒ 🔴 全部是**同一张乐音表**的音高变体
    //      ⇒ 🔴 听感 = "**音高不同的节拍器嘀嗒**"（⭐ 用户反馈的原始问题）✅
    //   ⭐ 本表由 `tools/gen_t31b_wavetable.py` 的 `generate_noise_table()` 生成：
    //      ⭐ **整数谐波 × 随机相位 × 等幅** ⇒ ⭐ 平坦谱（宽带）＋ **天然周期安全**
    //      （⭐ 环绕处不存在离群台阶）＋ ⭐ **天然零直流** ✅
    wire signed [WT_W-1:0] rom_noise;
    reg  [7:0] resp_velocity_q;

    always @(posedge clk_i) begin
        if (!rst_n_i)
            resp_velocity_q <= 8'd0;
        else if (req_active)
            resp_velocity_q <= req_velocity;
    end

    //  ⭐⭐ 2026-09-29 新增：⭐ **"本次请求是鼓吗"的 1 拍响应标签**（⭐ 与 ROM 数据同步 ✅）
    //   🔴 **为什么必须寄存一拍**（⭐ 这是本模块最容易写错的地方）：
    //      ⭐ pROM 的 `READ_MODE = 1'b0` ⇒ 数据**比地址晚 1 拍**回来（⭐ 见
    //         `wavetable_bank` 的注释与 `K-167` 前科）⇒ ⚠️ 若用**当前**的 `req_drum`
    //         去选表 ⇒ 🔴 选中的是**下一条 lane 的归属** ⇒ ⭐ **车道错位**
    //         （⭐ 与当年 `READ_MODE=1` 的坑**完全同型**：⭐ 数据与标签必须同拍 ✅）
    //   📌 写法与 `resp_velocity_q` **逐字同构**（⭐ 同一个 `req_active` 使能、
    //      ⭐ 同一个时钟沿）⇒ ⭐ 两者天然对齐 ✅
    reg resp_drum_q;

    always @(posedge clk_i) begin
        if (!rst_n_i)
            resp_drum_q <= 1'b0;
        else if (req_active)
            resp_drum_q <= req_drum;
    end

    //  ⭐⭐ 2026-09-29 合并（⭐ 队友版）：⭐ **默认【不】让力度改音色** ✅
    //   · ⭐ `VELOCITY_BLEND_EN = 1` ⇒ ⭐ 旧行为：⭐ `velocity=0` 取 soft · `255` 取 hard
    //   · ⭐ `VELOCITY_BLEND_EN = 0`（默认）⇒ ⭐ **固定 `FIXED_BLEND_Q`**（⭐ 0 = soft ✅）
    //   📌 无论哪档，**只有一个 TDM 乘法器**服务 64 条 lane ⇒ ⛔ 无额外 DSP ✅
    wire [8:0] velocity_mix_q = (resp_velocity_q == 8'hFF) ? 9'd256
                                                           : {1'b0, resp_velocity_q};
    localparam [8:0] FIXED_BLEND_Q_W = FIXED_BLEND_Q;
    wire [8:0] mix_q = (VELOCITY_BLEND_EN != 0) ? velocity_mix_q
                                                : FIXED_BLEND_Q_W;
    wire signed [WT_W:0] blend_delta = {rom_hard[WT_W-1], rom_hard}
                                     - {rom_soft[WT_W-1], rom_soft};
    wire signed [WT_W+9:0] blend_product = blend_delta * $signed({1'b0, mix_q});
    // The post-shift range is one signed sample delta (17 bits).  Slice it
    // explicitly before the add so synthesis sees no lossy width conversion.
    wire signed [WT_W:0] blend_scaled = blend_product[WT_W+8:8];
    wire signed [WT_W:0] blend_sum = {rom_soft[WT_W-1], rom_soft}
                                  + blend_scaled;
    //  ⭐⭐ 2026-09-29 修 bug②：⭐ **力度→音色 的耦合【默认关闭】**
    //   ⭐ `VEL_TIMBRE_BLEND = 0`（默认）⇒ ⭐ **固定 `rom_hard`**（⭐ 音色只由 `timbre` 决定）✅
    //   ⚠️ `blend_*` 那几根线**仍然保留引用**（⭐ 免得 `iverilog -Wall` 报未使用 ✅）——
    //      ⭐ 而 `VEL_TIMBRE_BLEND` 是**编译期常量** ⇒ ⭐ 综合器会把它们**整块折叠掉** ✅
    //  ⚠️⚠️ 2026-09-29 上板实测修正：⭐ **固定用 `rom_hard`，⛔ 不是 `rom_soft`**
    //   🔴 **为什么**：
    //      · ⭐ `rom_hard` 的 4 个块**互不相同**（⭐ 4 个音色可分辨 ✅）＋ ⭐ **满幅 32767** ✅
    //        ⇒ 🔴 而 `rom_soft`（⭐ 旧表：⭐ 4 块相同、峰值 16384）**听不出音色切换** ＋ **音量砍半** ✅
    //  ⭐⭐ 2026-09-29 深夜（⭐ T31b 波表合并后重写）：⭐ **Test Mode 用【专用纯正弦】表 `rom_test`** ✅
    //   🔴 **为什么必须专用**：⭐ 四音色换成 **AKWF 表**（⭐ 谐波丰富 ✅）⇒ ⭐ 若 Test Mode 借它们
    //      ⇒ 🔴 **谐波被 `peak_count` 数成谱峰** ⇒ 🔴 **M4 判据（谱峰数 = 4/8/16/32）变红** ✅
    //      （⭐ 实测前科：⭐ 三角波 `rom_hard` 的 1/9·1/25·1/49 谐波 = −19.08/−27.96/−33.80 dB
    //        ⇒ 🔴 全部高于 −40 dB 门限 ⇒ ⭐ 峰数被打成 **20/40/72/127** ✅ 见 `K-167` ✅）
    //   ⭐ Test Mode 是**测量模式**（⭐ 证明 ≥32 复音，⛔ 不是演奏音色）
    //      ⇒ ⭐ **与音色彻底解耦** ⇒ ⭐ 以后换任何波表都**不会再红** ✅
    //   📌 **不变式（⭐ 合波表的人必读）**：⭐ `rom_test` 必须是**纯正弦**
    //      ⇒ ⭐ 由 `tools/gen_t31b_wavetable.py` 的 `generate_test_sine()` 保证 ✅
    //      ⇒ ⭐ 合完波表**必须重跑** `sim\test_mode_fft.ps1` ✅
    //  ⭐⭐ 2026-09-29 合并：⭐ **演奏通路固定走 `blend_sum`**（⭐ 队友版 ✅）
    //   ⭐ `FIXED_BLEND_Q = 0` ⇒ ⭐ `blend_sum = rom_soft` ⇒ ⭐ 用 **AKWF 的 soft 表**（⭐ 平滑档 ✅）
    //   ⭐ Test Mode 仍走**专用纯正弦** `rom_test`（⭐ 我们的，⛔ 不借 AKWF ✅）
    //  ⭐⭐ 2026-09-29 新增（⭐ 鼓机噪声波表 · 阶段 2a）：⭐ **鼓 voice 改选噪声表** ✅
    //   ⭐ 优先级：⭐ `test_mode_i`（⭐ 测量模式，⭐ 必须纯正弦）> `resp_drum_q`（⭐ 鼓）> 乐音表 ✅
    //   ⭐ 为什么鼓排在 test 之后：⭐ Test Mode 的 M4 判据（谱峰数 4/8/16/32）建立在
    //      "**所有 lane 都是纯正弦**"之上 ⇒ ⭐ 若鼓 voice 在 test 下仍取噪声
    //      ⇒ 🔴 **谐波被 `peak_count` 数成谱峰** ⇒ 🔴 判据变红 ✅（⭐ 同 `rom_test` 的理由）
    //   ⭐ 为什么鼓排在乐音表之前：⭐ 这正是本阶段的**全部目的** ——
    //      ⭐ 让 hi-hat / snare / clap 不再是"音高不同的嘀嗒" ✅
    //   📌 **代价**：⭐ 一个 2:1 mux（16 位）＋ ⭐ **总共 1 个 FF** 的响应标签
    //      （⭐ `resp_drum_q` —— ⚠️ TDM 是**串行**的 ⇒ ⭐ 标签只需**一份**，
    //       ⛔ 不是每 lane 一份；⭐ 与 `resp_velocity_q` 完全同构 ✅）
    //      ⇒ ⭐ **零 DSP、零额外 pROM 读口**（⭐ 噪声表与乐音表**共用同一个地址** ✅）
    wire signed [WT_W-1:0] rom_dout = test_mode_i ? rom_test
                                                  : (resp_drum_q ? rom_noise
                                                                 : blend_sum[WT_W-1:0]);

    wavetable_bank #(
        .TIMBRE_N(TIMBRE_N), .TIMBRE_W(TIMBRE_W),
        .DEPTH(WT_DEPTH), .SAMPLE_W(WT_W)
    ) u_wavetable_bank (
        .clk_i    (clk_i),
        .rst_n_i  (rst_n_i),
        .rd_en_i  (req_active),
        .timbre_i (rom_timbre),
        .addr_i   (rom_ad),
        .sample_soft_o (rom_soft),
        .sample_hard_o (rom_hard),
        .sample_test_o (rom_test),
        //  ⭐⭐ 2026-09-29 新增：⭐ **第 10 张表 = 鼓机专用宽带噪声** ✅
        .sample_noise_o (rom_noise),
        .valid_o  ()
    );

    // ═══════════════════════════════════════════════════════════════════════
    // ④ 样本汇总：ROM 数据比地址**晚 1 拍**回来
    //    ⇒ 当 `cnt == k+1` 时，`rom_dout` 是 lane k 的样本
    // ═══════════════════════════════════════════════════════════════════════
    //  ⭐⭐ 2026-10-17：⭐ **两条实现，参数门控**（⭐ 见 `OSC_RAM_EN` 的长注释 ✅）
    //   · `OSC_RAM_EN == 0`（⭐ **默认**）⇒ ⭐ `sample_bus_r`：**1024 FF + 组合读**
    //     ⭐ 与原实现**逐字、逐位、逐拍完全一致** ✅
    //   · `OSC_RAM_EN == 1` ⇒ ⭐ `osc_ram`：**BSRAM + 2 个寄存器读口**
    //     ⭐ 写口每拍只写 1 个 lane（⭐ `cnt-1`）⇒ ⭐ 天然适合 RAM ✅
    //
    //  🔴 **实测（⭐ 不是推理）**：⭐ 这条"1 写 2 读"的写法 Gowin **能推断 RAM**
    //     （⭐ `Extracting RAM for identifier 'osc_ram'`）⇒ ⭐ 落成 **2 个 BSRAM**（⭐ 读口复制）
    //     ＋ ⭐ **LUT 1 / REG 0**（⭐ `build/exp_ram_infer/m_a.*` 实测）✅
    //     📌 **反面教材**：⭐ 同一次实测里，把数组拆成"偶/奇 lane 两个数组"
    //        ⇒ 🔴 **BSRAM 0 · REG 1056 · LUT 616**（⭐ 退回寄存器阵列 ⇒ 比不改还差）⛔
    //        ⇒ ⭐ **必须**保持这个"单数组 + 2 个读地址"的形状 ✅
    generate
        if (OSC_RAM_EN != 0) begin : g_osc_ram
            //  ⚠️ 数组**没有【同步】复位**（⭐ 那会直接把 BSRAM 推断搞掉）——
            //     ⭐ 但每帧 `cnt` 都会把 `0..LANES-1` **全部重写一遍**（⭐ 见 ② 的 TDM 时序）
            //     ⇒ ⭐ 渲染阶段读到的**必然是本帧数据** ✅
            //  ⭐⭐ **`initial` 上电清零**（⭐ 与老路径的"复位 = 0"逐位对齐 ✅）：
            //     ① ⭐ 仿真：⭐ 未写过的 lane 读 **0** 而⛔ 不是 `X`（🔴 否则 `xprop` 判据会红）
            //     ② ⭐ 综合：⭐ Gowin 会把初值写进位流/`.mi`（⭐ 实测**不影响 BSRAM 推断**：
            //        `build/exp_ram_infer/m_c.*` ⇒ ⭐ 仍然 **BSRAM 2 / LUT 1 / REG 0** ✅）
            //     ③ ⭐ 语义：⭐ 上电后**第一帧**即使渲染与扫描重叠，⭐ 读到的是 0 ⇒
            //        ⭐ 与老路径（`sample_bus_r` 复位为 0）**逐位相同** ✅
            reg [OSC_SAMPLE_W-1:0] osc_ram [0:LANES-1];
            reg [OSC_SAMPLE_W-1:0] osc_rd_data0_r;
            reg [OSC_SAMPLE_W-1:0] osc_rd_data1_r;
            integer ri;

            initial begin
                for (ri = 0; ri < LANES; ri = ri + 1)
                    osc_ram[ri] = {OSC_SAMPLE_W{1'b0}};
            end

            //  ⭐ 写口：⛔ **只有这一个** always 写 `osc_ram`（⭐ EX2000/EX1999 ✅）
            //  🔴 **纯写**（⭐ 不读回、⭐ 不掺同址旁路 ⇒ ⛔ 不会推断 write-through ✅）
            always @(posedge clk_i) begin
                if (rendering && (cnt >= 1) && (cnt <= LANES[LW:0]))
                    osc_ram[cnt-1] <= rom_dout;
            end

            //  ⭐ 读口：⭐ **纯读**（⭐ 只有 `mem[addr]` 这一种形态 ⇒ 无旁路 ✅）
            //     ⭐ 输出**寄存器**（⭐ 1 拍延迟）＋ ⭐ 复位清零（⭐ 与老路径的复位清零对齐 ✅）
            always @(posedge clk_i) begin
                if (!rst_n_i) begin
                    osc_rd_data0_r <= {OSC_SAMPLE_W{1'b0}};
                    osc_rd_data1_r <= {OSC_SAMPLE_W{1'b0}};
                end else begin
                    osc_rd_data0_r <= osc_ram[osc_rd_addr0_i];
                    osc_rd_data1_r <= osc_ram[osc_rd_addr1_i];
                end
            end

            assign osc_rd_data0_o   = osc_rd_data0_r;
            assign osc_rd_data1_o   = osc_rd_data1_r;
            //  ⚠️ 本模式下 `osc_sample_bus_o` **无意义**（⭐ 必须配 `tdm_render_mixer.OSC_SRC_RAM=1`）
            //     ⇒ ⭐ 恒 0（⭐ 避免悬空 X；⭐ 综合会把它整个折掉 ✅）
            assign osc_sample_bus_o = {(LANES*OSC_SAMPLE_W){1'b0}};
        end else begin : g_osc_ff
            reg [LANES*OSC_SAMPLE_W-1:0] sample_bus_r;
            integer si;

            always @(posedge clk_i) begin
                if (!rst_n_i) begin
                    sample_bus_r <= {(LANES*OSC_SAMPLE_W){1'b0}};
                end else if (rendering && (cnt >= 1) && (cnt <= LANES[LW:0])) begin
                    sample_bus_r[(cnt-1)*OSC_SAMPLE_W +: OSC_SAMPLE_W] <= rom_dout;
                end
            end

            assign osc_sample_bus_o = sample_bus_r;
            assign osc_rd_data0_o   = {OSC_SAMPLE_W{1'b0}};
            assign osc_rd_data1_o   = {OSC_SAMPLE_W{1'b0}};
        end
    endgenerate

    assign osc_valid_o      = valid_r;

    // ⭐ 调试观测：`DBG_LANE` 的相位（冻结表 §2.6：`phase_acc_dbg_o` 是"选定 lane 调试"）
    assign phase_acc_dbg_o  = lane_phase[DBG_LANE*PHASE_W +: PHASE_W];

    // ═══════════════════════════════════════════════════════════════════════
    // ⑤ ⚠️ 未实装项的**显式说明**（⛔ 不要静默忽略输入 —— 那正是 `K-88` 的坑）
    // ═══════════════════════════════════════════════════════════════════════
    //  · `voice_timbre_i`：`note_manager` 在 note_on 锁存的每 voice 音色；
    //    `wavetable_bank` 以它选择 BASS/GUITAR/PIANO/PAD 的 soft/hard 表，
    //    并按同一 voice 的力度做线性插值。后续全局音色变化不会改写在响 voice。
    //  · `fm_cfg_valid_i` / `fm_ratio_i` / `fm_index_i`：`ENABLE_FM=0` ⇒ **忽略**
    //    （`A2c`：FM 先留接口、后加，且**不计入吞吐量**）。
    //  · `TIMBRE_N`：当前固定为 4（BASS/GUITAR/PIANO/PAD）；表索引由
    //    `voice_timbre_i` 提供，参数必须与 wavetable_bank 保持一致。
    localparam integer TIMBRE_OK = (TIMBRE_N >= 1) && (TIMBRE_W >= 1);

    // ⚠️ 参数自检（与 `clk_gen`/`tlc5916`/`top` 的 `PARAM_OK` 同一套路）：
    //    ⭐ `LANES` 必须 ≤ `CLK_PER_SAMPLE`（1024），否则 **TDM 跑不完一帧**
    //       ⇒ ⛔ 帧内截止必然失败（`A6`），而且现象是"随机丢样本"，极难定位。
    initial begin
        if (LANES > 1024)
            $display("ERROR [oscillator_bank] LANES=%0d > 1024（每帧可用 clk 数）=> TDM 跑不完一帧，A6 必然失败",
                     LANES);
        if (!TIMBRE_OK)
            $display("ERROR [oscillator_bank] TIMBRE_N=%0d / TIMBRE_W=%0d 非法", TIMBRE_N, TIMBRE_W);
        if (ENABLE_FM != 0)
            $display("WARNING [oscillator_bank] ENABLE_FM=%0d 但 FM **尚未实装**（A2c：先留接口、后加）",
                     ENABLE_FM);
        //  ⭐⭐ 2026-09-30 新增（阶段 2b）：⭐ **扫频深度的【截断】自检** ✅
        //   🔴 为什么必须有（⭐ `K-106`：⛔ 不许静默失效 ✅）：
        //      ⭐ `sweep_q` 只有 `DRUM_SWEEP_W`(16) 位，⭐ 而装载值是
        //      `base_inc >> (LSB_SH + SH)` ⇒ ⚠️ 若有人把 `DRUM_SWEEP_LSB_SH`
        //      调小（⭐ 例如 0）、⭐ 或把 `DRUM_KICK_MAX` 调大 ⇒
        //      🔴 **高位移出被静默截断** ⇒ ⭐ 扫频深度**比参数说的小**，⭐ 且**毫无报错** ✅
        //   ⭐ 判据：⭐ 门限上界对应的深度必须**装得进** `DRUM_SWEEP_W` 位 ✅
        if ((DRUM_PITCH_ENV_EN != 0)
            && (((DRUM_KICK_MAX - 1) >> (DRUM_SWEEP_LSB_SH + DRUM_KICK_SWEEP_SH))
                >= (1 << DRUM_SWEEP_W)))
            $display("ERROR [oscillator_bank] 扫频深度被截断：DRUM_KICK_MAX=%0d >> (%0d+%0d) 超过 %0d 位",
                     DRUM_KICK_MAX, DRUM_SWEEP_LSB_SH, DRUM_KICK_SWEEP_SH, DRUM_SWEEP_W);
        if ((DRUM_PITCH_ENV_EN != 0) && (DRUM_CLICK_EN != 0))
            $display("WARNING [oscillator_bank] DRUM_CLICK_EN=%0d 但 **click 尚未实装**（阶段 2b 只做音高包络）",
                     DRUM_CLICK_EN);
    end

endmodule

`default_nettype wire
