/*
 * gatt_svc.c -- GATT 属性表定义（⭐ UUID 照抄 ESP-IDF 官方 ble_spp_server）
 * ============================================================================
 * 项目：FPGA2026 · ESP32-S3 BLE 版
 *
 * 【UUID 表 —— ⭐ 已拉官方源码核对，⛔ 不是凭印象】
 *   来源：esp-iot-solution/examples/bluetooth/ble_conn_mgr/ble_spp/spp_server/
 *         main/app_main.c
 *
 *     #define BLE_SVC_SPP_UUID16      0xABF0     // 服务（⭐ 16 位）
 *     #define BLE_SVC_SPP_CHR_UUID16  0xABF1     // 特征（⭐ 也是 16 位）
 *
 *   ⭐ 本工程按语义把特征拆成四个（官方示例只有一个 0xABF1）：
 *       0xABF0  服务
 *       0xABF1  接收  WRITE + WRITE_NR  ← ⭐ 对端把事件帧写这里
 *       0xABF2  通知  NOTIFY           ← ⭐ 我们 notify 回对端
 *       0xABF3  命令  WRITE + WRITE_NR（⭐ 与 0xABF1 共用属性变量）
 *       0xABF4  状态  READ + NOTIFY（⭐ 2026-10-15 起**周期性 notify**）
 *   ⭐ 为什么拆：语义与 SPP 版一致（收/发/命令/状态），
 *     且手机端用支持自定义 UUID 的现成 BLE 终端 App 即可对接，⛔ 不必自研 App。
 *   ⭐⭐ 2026-10-15：`0xABF1`/`0xABF3` 由"只有 WRITE_NR"改成
 *     **"WRITE + WRITE_NR"**（🔴 无确认写实测丢 39% 数据 —— 见 `s_prop_recv` 的注释）✅
 *   ⭐⭐ 2026-10-15：`0xABF4` 由"只能读"改成**周期性 notify**
 *     （🔴 客户端 readValue 会在 ESP32 忙时挂住 ⇒ Web Bluetooth 永久卡死
 *       —— 见 `ESP32侧需求-STAT周期性notify-20261014.md`）✅
 *
 * 🔴 本文件【只提供属性表与句柄索引】——
 *    ⚠️ 事件回调统一在 ble_main.c。ESP-IDF 的 gatts 回调注册是【全局】的，
 *       注册两次会互相覆盖 ⇒ 症状是"回调只触发一半"，极难查。
 * ============================================================================
 */

#include <string.h>

#include "esp_log.h"
#include "esp_bt.h"
#include "esp_gatts_api.h"

#include "ble_config.h"
#include "gatt_svc.h"

static const char *TAG = "gatt";

/* ---------------------------------------------------------------------------
 * 属性表索引（⚠️ 顺序必须与数组一致）
 * --------------------------------------------------------------------------- */
enum {
    IDX_SVC = 0,
    IDX_CHAR_RECV_DECL, IDX_CHAR_RECV_VAL,
    IDX_CHAR_NOTI_DECL, IDX_CHAR_NOTI_VAL, IDX_CHAR_NOTI_CFG,
    IDX_CHAR_CMD_DECL,  IDX_CHAR_CMD_VAL,
    IDX_CHAR_STAT_DECL, IDX_CHAR_STAT_VAL, IDX_CHAR_STAT_CFG,
    IDX_NUM,
};

/* ---------------------------------------------------------------------------
 * UUID（⭐ 全部 16 位 —— 见文件头说明）
 * --------------------------------------------------------------------------- */
static const uint16_t s_uuid_pri_svc  = ESP_GATT_UUID_PRI_SERVICE;
static const uint16_t s_uuid_char_dec = ESP_GATT_UUID_CHAR_DECLARE;
static const uint16_t s_uuid_cccd     = ESP_GATT_UUID_CHAR_CLIENT_CONFIG;

static const uint16_t s_uuid_svc  = BLE_SVC_UUID16;
static const uint16_t s_uuid_recv = BLE_CHR_RECV_UUID16;
static const uint16_t s_uuid_noti = BLE_CHR_NOTI_UUID16;
static const uint16_t s_uuid_cmd  = BLE_CHR_CMD_UUID16;
static const uint16_t s_uuid_stat = BLE_CHR_STAT_UUID16;

/* ⭐ 供 ble_main.c 放进广播数据 */
const uint16_t gatt_service_uuid16 = BLE_SVC_UUID16;

/* 特征属性
 * ---------------------------------------------------------------------------
 * ⭐⭐ 2026-10-15：**`0xABF1`/`0xABF3` 加 `WRITE`（带确认写）** ✅
 *   出处：`ESP32侧需求-0xABF1加WRITE位-20261014.md`（ESP32 线提出，🔴 阻塞）
 *
 * 🔴 **病因（实测，不是推测）**：原来只有 `WRITE_NR`（无确认写）
 *    · 网页交给 `writeValueWithoutResponse` 的字节 = **170460**
 *    · ESP32 实际收到                              = **104640**
 *    · ⇒ 🔴 **丢 65820 字节 = 39%**（⭐ 曲子"只有一截"）
 *    ⚠️ 而三条排除项一起说明**丢在链路层**：
 *        `ble.drop = 0`（⛔ 不是 `ble_buf_push()` 截断）
 *        上行环 0/163840（⛔ 不是环满）
 *        `ovf = 0`（⛔ 不是池满 —— 池已从 160 KB 提到 2 MB）
 *    🔴 **而 `WRITE_NR` 让丢包无法被发现**：浏览器把数据放进队列就
 *       **立刻 resolve**（⛔ 不等对端）⇒ 链路层丢包时两边都不知道 ✗
 *       ⇒ 只能靠 `tf=18935` vs `ev=11621` **事后**才发现 ✅
 *    📌 ESP32 侧已加节流（`PACING_MS=20`，实测 19.5 KB/s —— 对 BLE 很慢）
 *       ⛔ **仍然丢 39%** ⇒ ⭐ **说明这不是"发太快"，而是"无确认写本身不可靠"** ✅
 *
 * ✅ **修法（一行）**：加上 `ESP_GATT_CHAR_PROP_BIT_WRITE`
 *    ⭐ **`WRITE_NR` 保留** —— 老客户端不受影响，新客户端可选带确认写 ✓
 *    ⭐ **为什么这一行就够**：带确认写时浏览器要**等 ESP32 的 ATT 响应**
 *       才 resolve ⇒ ⭐ **天然流控** ⇒ 缓冲区满时对端不响应 ⇒ 浏览器自动等
 *       ⇒ 🔴 **不可能再丢** ✅
 *    ⚠️ **代价**：吞吐降一些（每次写等一个 ATT 往返）
 *       ⭐ 但**可靠 > 快**，而且 ESP32 侧会按"能确认的速率"发，总体更稳 ✅
 *
 * 📌 **`0xABF3`（命令）自动一起修好** —— ⭐ 它与 `0xABF1` **共用这个变量**
 *    （见下方 `IDX_CHAR_CMD_DECL`）⇒ ⛔ 不需要第二处改动 ✅
 *    ⭐ 而命令正是"1 字节、丢了后果也大"（用户实测出现过"发了起播但没反应"）
 *    ⇒ 一起加上是**对**的 ✅ */
static const uint8_t s_prop_recv = ESP_GATT_CHAR_PROP_BIT_READ |
                                   ESP_GATT_CHAR_PROP_BIT_WRITE |
                                   ESP_GATT_CHAR_PROP_BIT_WRITE_NR;
static const uint8_t s_prop_noti = ESP_GATT_CHAR_PROP_BIT_READ |
                                   ESP_GATT_CHAR_PROP_BIT_NOTIFY;

/* CCCD 初值：0 = 通知未开启（⭐ 客户端必须写 0x0001 才会收到 notify） */
static uint8_t s_cccd_noti[2] = { 0x00, 0x00 };
static uint8_t s_cccd_stat[2] = { 0x00, 0x00 };

/*
 * ⚠️ 每个"值属性"都要有自己的存储。
 *    ⭐ 容量 =【单次写】能进来的最大字节数，⛔ 不是总量。
 *    ⚠️ 整曲 104 KB 是靠【多次写】累加进来的 ——
 *       BLE 单包上限就是 MTU-3 ≈ 514 字节，一次写不了多少。
 *    ⭐ 512 对应协商 MTU 517，够用。
 */
static uint8_t s_val_recv[512];
static uint8_t s_val_noti[512];
static uint8_t s_val_cmd[64];
/* ⭐⭐ 2026-10-01：STAT 容量 64 → **256** → **320**
 * ---------------------------------------------------------------------------
 * ⚠️ 为什么原来只有 64：⭐ 当时只回一行短文本（`pool=.. sent=..`）。
 * 🔴 而现在要回**全状态**（**V1 / 池 / 环 / BLE / UART / HMI / 帧 / CMD 八组**）
 *    ⇒ ⚠️ 64 字节**装不下**（⭐ 实测完整状态约 210 字符）。
 *
 * 🔴🔴 **2026-10-01 二次扩容 256 → 320（⭐ 踩过一次）**：
 *    ⚠️ 加了 `hmi=` 行（⭐ 屏→ESP32 诊断）之后，⭐ 总长**超过 256**
 *    ⇒ 🔴 **`cmd` 行被静默截断**（⭐ 实测：读回 256 字节，⭐ 最后只剩 `cmd` 半个词）
 *    ⇒ ⭐ **教训：加字段时必须同时核对容量** —— ⚠️ 截断是**静默的**，
 *       ⭐ 不会报错，只会"少一组"（⭐ 同族 `C113`：错得看不出来）。
 *    📌 判据：⭐ `stat_read.py` 的"八组齐全"检查**能抓到**这个（⭐ 它确实抓到了）。
 *
 * 🔴🔴 **2026-10-12 三次扩容 320 → 512（⭐ 同一个坑踩了第二次）**：
 *    ⚠️ 加了 `ble.drop=` 与 `frame.ev=` 两个字段之后，⭐ 总长**超过 320**
 *    ⇒ 🔴 **`frame` 行被静默截断**（⭐ 实测读到 `frame=... rst=96 u` —— 断在 `u`）
 *    ⇒ ⚠️ 连带 `cmd` 组整组消失。
 *    📌 实测判据（⭐ 两个工具同时报错，指向同一处）：
 *       · `stat_read.py` 报「缺字段：cmd.unk」
 *       · `regress_live.py` 报 `ValueError: invalid literal for int(): '?'`
 *         （⭐ 它去解析被截断的尾巴，拿到的是乱码）
 *    ⭐ **教训（⭐ 第二次了，这次记死）**：⭐ **加字段的【同一次提交】里
 *       必须重算长度并核对容量** —— ⚠️ 截断是**静默的**，⛔ 不报错。
 *       ⚠️ 而且长度**会随数值位数变化**（`tf=18504` 比 `tf=200` 长 3 字节）
 *       ⇒ ⭐ 必须按【最坏情况】估，⛔ 不能按典型值估。
 *    ⭐ 512 的余量：当前最坏约 300 字节 ⇒ ✅ 留了约 200 字节余量。
 *
 * ⚠️ **读的约束（⭐ 必须知道）**：
 *    · ⭐ BLE 的**单次读**受 MTU 限制（⭐ `MTU-1` 字节）
 *    · ⚠️ 若对端 MTU 是默认 **23** ⇒ 🔴 **一次只能读回 22 字节**（⭐ 会被截断）
 *    · ⭐ 对端要么**协商大 MTU**（⭐ 我们已请求 517），⭐ 要么**分段读**
 *    📌 实测：`bleak` 会自动协商并处理长读 ⇒ ✅ 512 字节能一次读完。
 */
static uint8_t s_val_stat[512];
/* ⭐ 已写入 STAT 的字节数（⚠️ 属性表的 max_length 就是 sizeof(s_val_stat)） */
static size_t  s_stat_len = 0;


/* ---------------------------------------------------------------------------
 * 属性表
 * --------------------------------------------------------------------------- */
static const esp_gatts_attr_db_t s_db[IDX_NUM] = {
    /* ---- 服务声明 ---- */
    [IDX_SVC] = {
        { ESP_GATT_AUTO_RSP },
        { ESP_UUID_LEN_16, (uint8_t *)&s_uuid_pri_svc,
          ESP_GATT_PERM_READ, sizeof(uint16_t), sizeof(uint16_t),
          (uint8_t *)&s_uuid_svc }
    },

    /* ---- ① 0xABF1 接收：对端写数据进来 ---- */
    [IDX_CHAR_RECV_DECL] = {
        { ESP_GATT_AUTO_RSP },
        { ESP_UUID_LEN_16, (uint8_t *)&s_uuid_char_dec,
          ESP_GATT_PERM_READ, sizeof(uint8_t), sizeof(uint8_t),
          (uint8_t *)&s_prop_recv }
    },
    [IDX_CHAR_RECV_VAL] = {
        { ESP_GATT_RSP_BY_APP },              /* ⭐ 回调里自己回响应 */
        { ESP_UUID_LEN_16, (uint8_t *)&s_uuid_recv,
          ESP_GATT_PERM_READ | ESP_GATT_PERM_WRITE,
          sizeof(s_val_recv), 0, s_val_recv }
    },

    /* ---- ② 0xABF2 通知：我们发出去 ---- */
    [IDX_CHAR_NOTI_DECL] = {
        { ESP_GATT_AUTO_RSP },
        { ESP_UUID_LEN_16, (uint8_t *)&s_uuid_char_dec,
          ESP_GATT_PERM_READ, sizeof(uint8_t), sizeof(uint8_t),
          (uint8_t *)&s_prop_noti }
    },
    [IDX_CHAR_NOTI_VAL] = {
        { ESP_GATT_AUTO_RSP },
        { ESP_UUID_LEN_16, (uint8_t *)&s_uuid_noti,
          ESP_GATT_PERM_READ, sizeof(s_val_noti), 0, s_val_noti }
    },
    /* ⭐ CCCD —— 🔴 客户端**必须**写 0x0001 才收得到 notify。
     *    ⚠️ 漏了它的典型症状：**连上了、写数据也成功，但一路收不到任何东西**。 */
    [IDX_CHAR_NOTI_CFG] = {
        { ESP_GATT_AUTO_RSP },
        { ESP_UUID_LEN_16, (uint8_t *)&s_uuid_cccd,
          ESP_GATT_PERM_READ | ESP_GATT_PERM_WRITE,
          sizeof(uint16_t), sizeof(s_cccd_noti), s_cccd_noti }
    },

    /* ---- ③ 0xABF3 命令 ---- */
    [IDX_CHAR_CMD_DECL] = {
        { ESP_GATT_AUTO_RSP },
        { ESP_UUID_LEN_16, (uint8_t *)&s_uuid_char_dec,
          ESP_GATT_PERM_READ, sizeof(uint8_t), sizeof(uint8_t),
          (uint8_t *)&s_prop_recv }
    },
    [IDX_CHAR_CMD_VAL] = {
        { ESP_GATT_RSP_BY_APP },
        { ESP_UUID_LEN_16, (uint8_t *)&s_uuid_cmd,
          ESP_GATT_PERM_READ | ESP_GATT_PERM_WRITE,
          sizeof(s_val_cmd), 0, s_val_cmd }
    },

    /* ---- ④ 0xABF4 状态 ---- */
    [IDX_CHAR_STAT_DECL] = {
        { ESP_GATT_AUTO_RSP },
        { ESP_UUID_LEN_16, (uint8_t *)&s_uuid_char_dec,
          ESP_GATT_PERM_READ, sizeof(uint8_t), sizeof(uint8_t),
          (uint8_t *)&s_prop_noti }
    },
    [IDX_CHAR_STAT_VAL] = {
        /* 🔴🔴 2026-09-30 修复：原来用 `ESP_GATT_AUTO_RSP` + **`length = 0`**
         *    ⇒ ⚠️ 自动响应回的是【声明长度】= **0** ⇒ 🔴 **读回来永远是空串**
         *      （⭐ 实测：`read_gatt_char(0xABF4)` 得到 `b''`，⚠️ 而固件
         *        明明已经 `STAT updated: pool=...` 写进去了 —— ⚠️ 两头都对不上）。
         * ⭐ 正解：改成 **`ESP_GATT_RSP_BY_APP`** ⇒ ⭐ 由【我们】在 READ_EVT 里
         *    决定长度（⭐ 即 `s_stat_len` 那个"实际写入了多少"）。
         *    ⚠️ 代价：READ_EVT 里必须**自己回响应**（⭐ 否则对端等超时）。 */
        { ESP_GATT_RSP_BY_APP },
        { ESP_UUID_LEN_16, (uint8_t *)&s_uuid_stat,
          ESP_GATT_PERM_READ, sizeof(s_val_stat), 0, s_val_stat }
    },
    [IDX_CHAR_STAT_CFG] = {
        { ESP_GATT_AUTO_RSP },
        { ESP_UUID_LEN_16, (uint8_t *)&s_uuid_cccd,
          ESP_GATT_PERM_READ | ESP_GATT_PERM_WRITE,
          sizeof(uint16_t), sizeof(s_cccd_stat), s_cccd_stat }
    },
};

/* ---------------------------------------------------------------------------
 * 对外接口
 * --------------------------------------------------------------------------- */
const esp_gatts_attr_db_t *gatt_get_db(void) { return s_db; }

int gatt_idx_count(void) { return IDX_NUM; }
int gatt_idx_recv(void)  { return IDX_CHAR_RECV_VAL; }
int gatt_idx_noti(void)  { return IDX_CHAR_NOTI_VAL; }
int gatt_idx_cmd(void)   { return IDX_CHAR_CMD_VAL;  }
int gatt_idx_stat(void)  { return IDX_CHAR_STAT_VAL; }

/* ⭐⭐ 2026-09-30：CCCD（通知使能）句柄索引 —— ⭐ ble_main.c 用它判断
 * "对端到底订阅了没有"（🔴 那是能否发 notify 的**真正前提**，⛔ 不是"已连接"）。 */
int gatt_idx_noti_cccd(void) { return IDX_CHAR_NOTI_CFG; }
int gatt_idx_stat_cccd(void) { return IDX_CHAR_STAT_CFG; }

/* ⭐⭐ 2026-09-30（B 子集）：往 0xABF4(STAT) 里放内容
 * ---------------------------------------------------------------------------
 * ⚠️ 注意 STAT 是 **只读**，⭐ 且响应方式已改成 **`ESP_GATT_RSP_BY_APP`**
 *    （🔴 **⛔ 不是 `ESP_GATT_AUTO_RSP`** —— ⚠️ 本注释原来写的是 AUTO_RSP，
 *     那是 **2026-09-30 修复前**的状态，⭐ 已过时 ⇒ 🔴 **照它做会踩坑**：
 *     用 AUTO_RSP + `length=0` 时，⭐ 自动响应回的是**声明长度 = 0**
 *     ⇒ 🔴 **读回来永远是空串**（⭐ 实测过）。
 *     ⭐ 见 `s_db[IDX_CHAR_STAT_VAL]` 的注释，⭐ 那里记了完整因果。)
 * ⇒ ⭐ **固件【不 notify】它**（⭐ 虽然属性位含 `NOTIFY`，⚠️ 但本工程不发），
 *    客户端只能【主动读】。
 * ⇒ ⭐ 所以"上报状态"= **先把内容写进 `s_val_stat`，等客户端来读**。
 *    ⚠️ 若客户端不读，那这次调用只更新了内容（⭐ 不是"发失败了"）。
 * ⚠️ 而 `RSP_BY_APP` 的**代价**：⭐ 长度必须由**我们在 READ_EVT 里显式给**
 *    ⇒ ⚠️ 忘了给就会回空串（⭐ 见 `gatt_set_stat` 的说明）。 */
void gatt_set_stat(const uint8_t *data, size_t n)
{
    if (data == NULL || n == 0) {
        return;
    }
    /* 🔴🔴 2026-10-01 修复：原来是【追加】⇒ ⚠️ 重复上报会**首尾相连**
     * -----------------------------------------------------------------------
     * ⚠️ 原写法：`cur = s_stat_len; memcpy(s_val_stat + cur, ...)` 满了才回绕
     * 🔴 症状：⭐ 客户端连发两次 `CMD 0x02` ⇒ 读回
     *      `pool=0/18204 ...\npool=0/18204 ...\n`  ← ⚠️ 两行拼一起
     * ⭐ 而 STAT 的语义是【当前状态的快照】⇒ ⭐ **每次都应【整体替换**，
     *    ⛔ 不是"往日志里追加"。
     * ⇒ ⭐ 改为**从 0 开始覆盖**（⭐ 这样每次读到的都是**最新一次**的完整状态）。 */
    if (n > sizeof(s_val_stat)) {
        n = sizeof(s_val_stat);          /* ⚠️ 截断到属性表声明的长度 */
    }
    memcpy(s_val_stat, data, n);
    s_stat_len = n;
}

/* ⭐⭐ 2026-09-30：把 STAT 的**内容指针 + 实际长度**交出去
 * ---------------------------------------------------------------------------
 * 🔴 为什么需要它：STAT 改成了 `ESP_GATT_RSP_BY_APP` ⇒ ⭐ 长度必须由
 *    `ble_main.c` 的 READ_EVT **自己填**。⚠️ 而 `s_val_stat`/`s_stat_len`
 *    是本文件的 static ⇒ ⭐ 必须通过函数暴露，⛔ 不能让调用方猜格式。
 * ⭐ 返回：实际长度；`*out` 指向内容（⚠️ 只读，⛔ 不要改）。 */
size_t gatt_get_stat(const uint8_t **out)
{
    if (out != NULL) {
        *out = s_val_stat;
    }
    /* ⚠️ 夹一下：防止越界（⭐ 属性表声明的 max_length 就是 sizeof(s_val_stat)） */
    return (s_stat_len <= sizeof(s_val_stat)) ? s_stat_len : sizeof(s_val_stat);
}

void gatt_log_layout(int svc, int recv, int noti, int cmd, int stat)
{
    ESP_LOGI(TAG, "attr table created OK");
    ESP_LOGI(TAG, "  svc  0x%04X  handle=%d", BLE_SVC_UUID16, svc);
    ESP_LOGI(TAG, "  0x%04X RECV handle=%d  <- peer WRITES here",
             BLE_CHR_RECV_UUID16, recv);
    ESP_LOGI(TAG, "  0x%04X NOTI handle=%d  <- we notify here",
             BLE_CHR_NOTI_UUID16, noti);
    ESP_LOGI(TAG, "  0x%04X CMD  handle=%d", BLE_CHR_CMD_UUID16, cmd);
    ESP_LOGI(TAG, "  0x%04X STAT handle=%d", BLE_CHR_STAT_UUID16, stat);
    ESP_LOGI(TAG, "  REMINDER: peer MUST write CCCD=0x0001 to get notifications");
}
